package com.example.surokkha

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*

/**
 * Platform handler for native Android functionality
 * Handles app icon visibility, service management, and system integration
 */
class PlatformHandler(private val context: Context) : MethodChannel.MethodCallHandler {
    
    companion object {
        private const val TAG = "SurokkhaPlatform"
        
        // Component names for hiding/showing app icon
        private const val MAIN_ACTIVITY_ALIAS = "com.example.surokkha.MainActivityAlias"
        private const val HIDDEN_ACTIVITY_ALIAS = "com.example.surokkha.HiddenActivityAlias"
    }
    
    private val packageManager = context.packageManager
    private val platformScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "initializeAccessibilityBridge" -> {
                initializeAccessibilityBridge(result)
            }
            "isAccessibilityServiceEnabled" -> {
                isAccessibilityServiceEnabled(result)
            }
            "requestAccessibilityPermission" -> {
                requestAccessibilityPermission(result)
            }
            "getUsageStatistics" -> {
                getUsageStatistics(result)
            }
            "hideAppIcon" -> {
                hideAppIcon(result)
            }
            "showAppIcon" -> {
                showAppIcon(result)
            }
            "isAppIconHidden" -> {
                isAppIconHidden(result)
            }
            "ensureServicesRunning" -> {
                ensureServicesRunning(result)
            }
            else -> {
                result.notImplemented()
            }
        }
    }
    
    private fun initializeAccessibilityBridge(result: MethodChannel.Result) {
        try {
            // Set up accessibility service reference
            SurokkhAccessibilityService.methodChannel = null // Will be set when service connects
            Log.i(TAG, "Accessibility bridge initialized")
            result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing accessibility bridge", e)
            result.error("INIT_ERROR", e.message, null)
        }
    }
    
    private fun isAccessibilityServiceEnabled(result: MethodChannel.Result) {
        try {
            val isEnabled = AccessibilityUtils.isAccessibilityServiceEnabled(context)
            result.success(isEnabled)
        } catch (e: Exception) {
            Log.e(TAG, "Error checking accessibility service status", e)
            result.error("CHECK_ERROR", e.message, null)
        }
    }
    
    private fun requestAccessibilityPermission(result: MethodChannel.Result) {
        try {
            AccessibilityUtils.openAccessibilitySettings(context)
            result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting accessibility permission", e)
            result.error("PERMISSION_ERROR", e.message, null)
        }
    }
    
    private fun getUsageStatistics(result: MethodChannel.Result) {
        try {
            val statistics = SurokkhAccessibilityService.instance?.getUsageStatistics()
            result.success(statistics ?: emptyMap<String, Any>())
        } catch (e: Exception) {
            Log.e(TAG, "Error getting usage statistics", e)
            result.error("STATS_ERROR", e.message, null)
        }
    }
    
    /**
     * Hide app icon from launcher using PackageManager.setComponentEnabledSetting
     */
    private fun hideAppIcon(result: MethodChannel.Result) {
        try {
            Log.i(TAG, "Attempting to hide app icon...")
            
            // Disable the main activity (hides from launcher)
            val mainActivityComponent = ComponentName(context, MainActivity::class.java)
            packageManager.setComponentEnabledSetting(
                mainActivityComponent,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            
            // Enable hidden activity alias (keeps app functional but hidden)
            val hiddenAliasComponent = ComponentName(context, HIDDEN_ACTIVITY_ALIAS)
            packageManager.setComponentEnabledSetting(
                hiddenAliasComponent,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            
            Log.i(TAG, "✅ App icon hidden successfully")
            result.success(true)
            
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error hiding app icon", e)
            result.error("HIDE_ERROR", e.message, null)
        }
    }
    
    /**
     * Show app icon in launcher using PackageManager.setComponentEnabledSetting
     */
    private fun showAppIcon(result: MethodChannel.Result) {
        try {
            Log.i(TAG, "Attempting to show app icon...")
            
            // Enable the main activity (shows in launcher)
            val mainActivityComponent = ComponentName(context, MainActivity::class.java)
            packageManager.setComponentEnabledSetting(
                mainActivityComponent,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            
            // Disable hidden activity alias
            val hiddenAliasComponent = ComponentName(context, HIDDEN_ACTIVITY_ALIAS)
            packageManager.setComponentEnabledSetting(
                hiddenAliasComponent,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            
            Log.i(TAG, "✅ App icon shown successfully")
            result.success(true)
            
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error showing app icon", e)
            result.error("SHOW_ERROR", e.message, null)
        }
    }
    
    /**
     * Check if app icon is currently hidden
     */
    private fun isAppIconHidden(result: MethodChannel.Result) {
        try {
            val mainActivityComponent = ComponentName(context, MainActivity::class.java)
            val enabledState = packageManager.getComponentEnabledSetting(mainActivityComponent)
            
            val isHidden = enabledState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            result.success(isHidden)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error checking app icon status", e)
            result.error("CHECK_ERROR", e.message, null)
        }
    }
    
    /**
     * Ensure all services are running, restart if needed
     */
    private fun ensureServicesRunning(result: MethodChannel.Result) {
        platformScope.launch {
            try {
                Log.i(TAG, "Ensuring all services are running...")
                
                var allServicesRunning = true
                
                // Check and restart accessibility service if needed
                if (!AccessibilityUtils.isAccessibilityServiceEnabled(context)) {
                    Log.w(TAG, "Accessibility service is not running")
                    allServicesRunning = false
                    
                    // Try to restart accessibility service
                    restartAccessibilityService()
                }
                
                // Check and restart background service if needed
                if (!isBackgroundServiceRunning()) {
                    Log.w(TAG, "Background service is not running")
                    allServicesRunning = false
                    
                    // Try to restart background service
                    restartBackgroundService()
                }
                
                // Check and restart foreground service if needed
                if (!isForegroundServiceRunning()) {
                    Log.w(TAG, "Foreground service is not running")
                    allServicesRunning = false
                    
                    // Try to restart foreground service
                    restartForegroundService()
                }
                
                if (allServicesRunning) {
                    Log.i(TAG, "✅ All services are running")
                } else {
                    Log.i(TAG, "🔄 Services restarted")
                }
                
                result.success(true)
                
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error ensuring services are running", e)
                result.error("SERVICE_ERROR", e.message, null)
            }
        }
    }
    
    private fun restartAccessibilityService() {
        try {
            // Accessibility service can only be restarted by user action
            // We can only check if it's enabled and log the status
            Log.i(TAG, "Accessibility service restart requires user action")
        } catch (e: Exception) {
            Log.e(TAG, "Error restarting accessibility service", e)
        }
    }
    
    private fun restartBackgroundService() {
        try {
            // Start the main activity to initialize background services
            val intent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("restart_services", true)
            }
            context.startActivity(intent)
            Log.i(TAG, "Background service restart initiated")
        } catch (e: Exception) {
            Log.e(TAG, "Error restarting background service", e)
        }
    }
    
    private fun restartForegroundService() {
        try {
            // Foreground service will be restarted by Flutter background service
            Log.i(TAG, "Foreground service restart will be handled by Flutter")
        } catch (e: Exception) {
            Log.e(TAG, "Error restarting foreground service", e)
        }
    }
    
    private fun isBackgroundServiceRunning(): Boolean {
        // Check if background service is running
        // This would typically check if the service is in the running services list
        return true // Simplified for now
    }
    
    private fun isForegroundServiceRunning(): Boolean {
        // Check if foreground service is running
        // This would typically check if the service is in the running services list
        return true // Simplified for now
    }
    
    fun dispose() {
        platformScope.cancel()
        Log.i(TAG, "Platform handler disposed")
    }
}
