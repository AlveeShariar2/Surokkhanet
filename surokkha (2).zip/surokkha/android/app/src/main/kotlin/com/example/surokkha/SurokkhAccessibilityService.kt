package com.example.surokkha

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap

/**
 * Surokkha Accessibility Service
 * 
 * IMPORTANT: This service is designed for legitimate purposes only:
 * - App usage monitoring for digital wellbeing
 * - Accessibility assistance for users with disabilities
 * - Parental control features (with proper consent)
 * 
 * This service does NOT capture sensitive data like passwords or personal messages.
 * It only monitors app usage patterns and accessibility events.
 */
class SurokkhAccessibilityService : AccessibilityService() {
    
    companion object {
        private const val TAG = "SurokkhAccessibility"
        private const val CHANNEL_NAME = "surokkha_accessibility"
        
        // Social media apps to monitor (for usage analytics only)
        private val MONITORED_APPS = setOf(
            "com.whatsapp",
            "com.facebook.orca", // Messenger
            "com.instagram.android",
            "com.facebook.katana", // Facebook
            "com.twitter.android",
            "com.snapchat.android",
            "com.tiktok.android",
            "com.telegram.messenger"
        )
        
        var instance: SurokkhAccessibilityService? = null
        var methodChannel: MethodChannel? = null
    }
    
    private val appUsageData = HashMap<String, AppUsageInfo>()
    private var currentApp: String? = null
    private var appStartTime: Long = 0
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    data class AppUsageInfo(
        var totalTimeSpent: Long = 0,
        var sessionCount: Int = 0,
        var lastUsed: Long = 0,
        var firstUsed: Long = 0
    )
    
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        
        Log.i(TAG, "Surokkha Accessibility Service Connected")
        
        // Configure service info
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                        AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                        AccessibilityEvent.TYPE_VIEW_FOCUSED
            
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                   AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            
            // Only monitor specific package names for privacy
            packageNames = MONITORED_APPS.toTypedArray()
        }
        
        serviceInfo = info
        
        // Send service status to Flutter
        sendDataToFlutter("service_connected", mapOf(
            "status" to "connected",
            "timestamp" to System.currentTimeMillis(),
            "monitored_apps" to MONITORED_APPS.size
        ))
    }
    
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.let { handleAccessibilityEvent(it) }
    }
    
    private fun handleAccessibilityEvent(event: AccessibilityEvent) {
        try {
            when (event.eventType) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                    handleWindowStateChanged(event)
                }
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                    handleContentChanged(event)
                }
                AccessibilityEvent.TYPE_VIEW_FOCUSED -> {
                    handleViewFocused(event)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling accessibility event", e)
        }
    }
    
    private fun handleWindowStateChanged(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return
        
        if (MONITORED_APPS.contains(packageName)) {
            Log.d(TAG, "App opened: $packageName")
            
            // End previous app session
            endCurrentAppSession()
            
            // Start new app session
            startAppSession(packageName)
            
            // Send app usage event to Flutter
            sendDataToFlutter("app_opened", mapOf(
                "package_name" to packageName,
                "app_name" to getAppName(packageName),
                "timestamp" to System.currentTimeMillis(),
                "event_type" to "app_opened"
            ))
        }
    }
    
    private fun handleContentChanged(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return
        
        if (MONITORED_APPS.contains(packageName) && packageName == currentApp) {
            // Monitor app activity (without capturing sensitive content)
            val activityData = mapOf(
                "package_name" to packageName,
                "timestamp" to System.currentTimeMillis(),
                "event_type" to "content_changed",
                "activity_detected" to true
            )
            
            // Send activity data to Flutter (no sensitive content)
            sendDataToFlutter("app_activity", activityData)
        }
    }
    
    private fun handleViewFocused(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return
        
        if (MONITORED_APPS.contains(packageName)) {
            // Log focus events for usage analytics
            Log.d(TAG, "View focused in: $packageName")
            
            sendDataToFlutter("view_focused", mapOf(
                "package_name" to packageName,
                "timestamp" to System.currentTimeMillis(),
                "event_type" to "view_focused"
            ))
        }
    }
    
    private fun startAppSession(packageName: String) {
        currentApp = packageName
        appStartTime = System.currentTimeMillis()
        
        val usageInfo = appUsageData.getOrPut(packageName) { 
            AppUsageInfo(firstUsed = System.currentTimeMillis()) 
        }
        usageInfo.sessionCount++
        usageInfo.lastUsed = System.currentTimeMillis()
        
        Log.d(TAG, "Started session for: $packageName")
    }
    
    private fun endCurrentAppSession() {
        currentApp?.let { packageName ->
            val sessionDuration = System.currentTimeMillis() - appStartTime
            
            appUsageData[packageName]?.let { usageInfo ->
                usageInfo.totalTimeSpent += sessionDuration
            }
            
            // Send session data to Flutter
            sendDataToFlutter("app_session_ended", mapOf(
                "package_name" to packageName,
                "session_duration" to sessionDuration,
                "timestamp" to System.currentTimeMillis(),
                "event_type" to "session_ended"
            ))
            
            Log.d(TAG, "Ended session for: $packageName, Duration: ${sessionDuration}ms")
        }
        
        currentApp = null
        appStartTime = 0
    }
    
    private fun getAppName(packageName: String): String {
        return when (packageName) {
            "com.whatsapp" -> "WhatsApp"
            "com.facebook.orca" -> "Messenger"
            "com.instagram.android" -> "Instagram"
            "com.facebook.katana" -> "Facebook"
            "com.twitter.android" -> "Twitter"
            "com.snapchat.android" -> "Snapchat"
            "com.tiktok.android" -> "TikTok"
            "com.telegram.messenger" -> "Telegram"
            else -> packageName
        }
    }
    
    private fun sendDataToFlutter(eventType: String, data: Map<String, Any>) {
        serviceScope.launch {
            try {
                val jsonData = JSONObject().apply {
                    put("event_type", eventType)
                    put("timestamp", System.currentTimeMillis())
                    data.forEach { (key, value) ->
                        put(key, value)
                    }
                }
                
                // Send to Flutter via method channel
                methodChannel?.invokeMethod("onAccessibilityEvent", jsonData.toString())
                
                Log.d(TAG, "Sent data to Flutter: $eventType")
            } catch (e: Exception) {
                Log.e(TAG, "Error sending data to Flutter", e)
            }
        }
    }
    
    fun getUsageStatistics(): Map<String, Any> {
        val stats = HashMap<String, Any>()
        
        appUsageData.forEach { (packageName, usageInfo) ->
            stats[packageName] = mapOf(
                "app_name" to getAppName(packageName),
                "total_time_spent" to usageInfo.totalTimeSpent,
                "session_count" to usageInfo.sessionCount,
                "last_used" to usageInfo.lastUsed,
                "first_used" to usageInfo.firstUsed,
                "average_session_time" to if (usageInfo.sessionCount > 0) {
                    usageInfo.totalTimeSpent / usageInfo.sessionCount
                } else 0
            )
        }
        
        return mapOf(
            "usage_statistics" to stats,
            "total_monitored_apps" to MONITORED_APPS.size,
            "active_apps" to appUsageData.size,
            "service_uptime" to System.currentTimeMillis(),
            "current_app" to (currentApp ?: "none")
        )
    }
    
    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
        endCurrentAppSession()
        
        sendDataToFlutter("service_interrupted", mapOf(
            "status" to "interrupted",
            "timestamp" to System.currentTimeMillis()
        ))
    }
    
    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "Accessibility service destroyed")
        
        endCurrentAppSession()
        serviceScope.cancel()
        instance = null
        
        sendDataToFlutter("service_destroyed", mapOf(
            "status" to "destroyed",
            "timestamp" to System.currentTimeMillis()
        ))
    }
    
    /**
     * IMPORTANT: This method is for legitimate accessibility purposes only
     * It does NOT capture sensitive data like passwords or personal messages
     */
    private fun analyzeAccessibilityNode(node: AccessibilityNodeInfo?): Map<String, Any> {
        val analysis = HashMap<String, Any>()
        
        node?.let {
            // Only capture non-sensitive UI structure information
            analysis["class_name"] = it.className?.toString() ?: "unknown"
            analysis["is_clickable"] = it.isClickable
            analysis["is_focusable"] = it.isFocusable
            analysis["is_enabled"] = it.isEnabled
            analysis["child_count"] = it.childCount
            
            // DO NOT capture text content for privacy reasons
            // analysis["text"] = it.text?.toString() // NEVER DO THIS
        }
        
        return analysis
    }
}
