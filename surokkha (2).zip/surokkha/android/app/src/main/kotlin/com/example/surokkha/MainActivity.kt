package com.example.surokkha

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.os.Bundle
import android.util.Log

class MainActivity: FlutterActivity() {
    
    companion object {
        private const val TAG = "SurokkhMainActivity"
        private const val PLATFORM_CHANNEL = "com.example.surokkha/platform"
        private const val ACCESSIBILITY_CHANNEL = "com.example.surokkha/accessibility"
        private const val HEALTH_CHECK_CHANNEL = "com.example.surokkha/health_check"
    }
    
    private lateinit var platformHandler: PlatformHandler
    private lateinit var healthCheckHandler: HealthCheckHandler
    
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        // Initialize handlers
        platformHandler = PlatformHandler(this)
        healthCheckHandler = HealthCheckHandler(this)
        
        // Setup method channels
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, PLATFORM_CHANNEL)
            .setMethodCallHandler(platformHandler)
            
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, ACCESSIBILITY_CHANNEL)
            .setMethodCallHandler(platformHandler)
            
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, HEALTH_CHECK_CHANNEL)
            .setMethodCallHandler(healthCheckHandler)
        
        // Set up accessibility method channel for service communication
        val accessibilityChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, ACCESSIBILITY_CHANNEL)
        SurokkhAccessibilityService.methodChannel = accessibilityChannel
        
        Log.i(TAG, "Flutter engine configured with platform and accessibility channels")
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Handle intent extras for service restart scenarios
        handleIntentExtras()
        
        Log.i(TAG, "MainActivity created")
    }
    
    private fun handleIntentExtras() {
        intent?.let { intent ->
            val restartReason = intent.getStringExtra("restart_reason")
            val autoRestart = intent.getBooleanExtra("auto_restart", false)
            val backgroundStart = intent.getBooleanExtra("background_start", false)
            
            if (autoRestart) {
                Log.i(TAG, "App started for auto-restart (reason: $restartReason)")
                
                if (backgroundStart) {
                    // If this is a background start, we might want to minimize or hide the activity
                    Log.d(TAG, "Background start detected - app started for service initialization")
                }
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        
        // Clean up handlers
        if (::platformHandler.isInitialized) {
            platformHandler.dispose()
        }
        if (::healthCheckHandler.isInitialized) {
            healthCheckHandler.dispose()
        }
        
        Log.i(TAG, "MainActivity destroyed")
    }
    
    override fun onResume() {
        super.onResume()
        
        // Log accessibility service status when app comes to foreground
        AccessibilityUtils.logServiceStatus(this)
        
        Log.d(TAG, "MainActivity resumed")
    }
}
