package com.example.surokkha

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.accessibility.AccessibilityManager

/**
 * Utility class for accessibility service operations
 */
object AccessibilityUtils {
    
    private const val TAG = "AccessibilityUtils"
    
    /**
     * Check if the Surokkha accessibility service is enabled
     */
    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        return try {
            val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
            
            val serviceName = "${context.packageName}/${SurokkhAccessibilityService::class.java.name}"
            
            if (!TextUtils.isEmpty(enabledServices)) {
                val colonSplitter = TextUtils.SimpleStringSplitter(':')
                colonSplitter.setString(enabledServices)
                
                while (colonSplitter.hasNext()) {
                    val componentName = colonSplitter.next()
                    if (componentName.equals(serviceName, ignoreCase = true)) {
                        Log.d(TAG, "✅ Accessibility service is enabled: $serviceName")
                        return true
                    }
                }
            }
            
            Log.d(TAG, "❌ Accessibility service is not enabled: $serviceName")
            false
        } catch (e: Exception) {
            Log.e(TAG, "Error checking accessibility service status", e)
            false
        }
    }
    
    /**
     * Open accessibility settings for user to enable the service
     */
    fun openAccessibilitySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Log.i(TAG, "Opened accessibility settings")
        } catch (e: Exception) {
            Log.e(TAG, "Error opening accessibility settings", e)
            
            // Fallback to general settings
            try {
                val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
                Log.i(TAG, "Opened general settings as fallback")
            } catch (fallbackException: Exception) {
                Log.e(TAG, "Error opening fallback settings", fallbackException)
            }
        }
    }
    
    /**
     * Get list of all enabled accessibility services
     */
    fun getEnabledAccessibilityServices(context: Context): List<String> {
        return try {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
            
            if (!TextUtils.isEmpty(enabledServices)) {
                val colonSplitter = TextUtils.SimpleStringSplitter(':')
                colonSplitter.setString(enabledServices)
                
                val servicesList = mutableListOf<String>()
                while (colonSplitter.hasNext()) {
                    servicesList.add(colonSplitter.next())
                }
                servicesList
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting enabled accessibility services", e)
            emptyList()
        }
    }
    
    /**
     * Check if accessibility is enabled on the device
     */
    fun isAccessibilityEnabled(context: Context): Boolean {
        return try {
            val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            accessibilityManager.isEnabled
        } catch (e: Exception) {
            Log.e(TAG, "Error checking if accessibility is enabled", e)
            false
        }
    }
    
    /**
     * Get accessibility service info for our service
     */
    fun getServiceInfo(context: Context): AccessibilityServiceInfo? {
        return try {
            val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            val enabledServices = accessibilityManager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            
            val serviceName = "${context.packageName}/${SurokkhAccessibilityService::class.java.name}"
            
            enabledServices.find { serviceInfo ->
                serviceInfo.id == serviceName
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting service info", e)
            null
        }
    }
    
    /**
     * Check if our accessibility service has the required permissions
     */
    fun hasRequiredPermissions(context: Context): Boolean {
        return try {
            val serviceInfo = getServiceInfo(context)
            serviceInfo?.let { info ->
                // Check if service has the required event types and capabilities
                val hasWindowStateChanged = (info.eventTypes and android.view.accessibility.AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) != 0
                val hasWindowContentChanged = (info.eventTypes and android.view.accessibility.AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) != 0
                val canRetrieveWindowContent = info.flags and AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS != 0
                
                hasWindowStateChanged && hasWindowContentChanged && canRetrieveWindowContent
            } ?: false
        } catch (e: Exception) {
            Log.e(TAG, "Error checking required permissions", e)
            false
        }
    }
    
    /**
     * Log accessibility service status for debugging
     */
    fun logServiceStatus(context: Context) {
        try {
            Log.d(TAG, "=== Accessibility Service Status ===")
            Log.d(TAG, "Accessibility Enabled: ${isAccessibilityEnabled(context)}")
            Log.d(TAG, "Service Enabled: ${isAccessibilityServiceEnabled(context)}")
            Log.d(TAG, "Has Required Permissions: ${hasRequiredPermissions(context)}")
            
            val enabledServices = getEnabledAccessibilityServices(context)
            Log.d(TAG, "All Enabled Services: $enabledServices")
            
            val serviceInfo = getServiceInfo(context)
            serviceInfo?.let { info ->
                Log.d(TAG, "Service Info - ID: ${info.id}")
                Log.d(TAG, "Service Info - Event Types: ${info.eventTypes}")
                Log.d(TAG, "Service Info - Flags: ${info.flags}")
                Log.d(TAG, "Service Info - Package Names: ${info.packageNames?.joinToString(", ")}")
            }
            Log.d(TAG, "================================")
        } catch (e: Exception) {
            Log.e(TAG, "Error logging service status", e)
        }
    }
}
