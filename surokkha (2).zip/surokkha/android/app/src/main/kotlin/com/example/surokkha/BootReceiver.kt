package com.example.surokkha

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.*

/**
 * Enhanced boot receiver to automatically restart services after device reboot or manual kill
 * Ensures persistent operation even when app is removed from recent apps
 */
class BootReceiver : BroadcastReceiver() {
    
    companion object {
        private const val TAG = "SurokkhBootReceiver"
        private const val RESTART_DELAY_MS = 5000L // 5 seconds delay before restart
        private const val MAX_RESTART_ATTEMPTS = 3
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        Log.i(TAG, "Boot receiver triggered: ${intent.action}")
        
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> {
                Log.i(TAG, "Device boot completed - preparing to restart services")
                scheduleServiceRestart(context, "boot_completed")
            }
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_PACKAGE_REPLACED -> {
                Log.i(TAG, "Package updated - preparing to restart services")
                scheduleServiceRestart(context, "package_updated")
            }
            Intent.ACTION_USER_PRESENT -> {
                Log.i(TAG, "User present - checking service status")
                checkAndRestartServices(context, "user_present")
            }
            Intent.ACTION_SCREEN_ON -> {
                Log.i(TAG, "Screen on - ensuring services are running")
                checkAndRestartServices(context, "screen_on")
            }
        }
    }
    
    /**
     * Schedule service restart with delay to ensure system is ready
     */
    private fun scheduleServiceRestart(context: Context, reason: String) {
        Handler(Looper.getMainLooper()).postDelayed({
            restartServices(context, reason)
        }, RESTART_DELAY_MS)
    }
    
    /**
     * Check if services are running and restart if needed
     */
    private fun checkAndRestartServices(context: Context, reason: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Check accessibility service status
                val isAccessibilityEnabled = AccessibilityUtils.isAccessibilityServiceEnabled(context)
                
                if (!isAccessibilityEnabled) {
                    Log.w(TAG, "Accessibility service not running - restarting services")
                    restartServices(context, reason)
                } else {
                    Log.d(TAG, "Services appear to be running")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error checking service status", e)
                // If we can't check, try to restart anyway
                restartServices(context, reason)
            }
        }
    }
    
    /**
     * Restart all services with multiple strategies
     */
    private fun restartServices(context: Context, reason: String) {
        CoroutineScope(Dispatchers.IO).launch {
            var attempts = 0
            
            while (attempts < MAX_RESTART_ATTEMPTS) {
                attempts++
                
                try {
                    Log.i(TAG, "Service restart attempt $attempts/$MAX_RESTART_ATTEMPTS (reason: $reason)")
                    
                    // Strategy 1: Start main activity to initialize services
                    startMainActivity(context, reason)
                    
                    // Strategy 2: Start services directly if possible
                    startServicesDirectly(context)
                    
                    // Strategy 3: Send broadcast to wake up services
                    sendWakeupBroadcast(context)
                    
                    // Wait a bit and check if services started
                    delay(3000)
                    
                    if (AccessibilityUtils.isAccessibilityServiceEnabled(context)) {
                        Log.i(TAG, "✅ Services restarted successfully on attempt $attempts")
                        break
                    } else {
                        Log.w(TAG, "⚠️ Services not detected after attempt $attempts")
                    }
                    
                } catch (e: Exception) {
                    Log.e(TAG, "❌ Error in restart attempt $attempts", e)
                }
                
                if (attempts < MAX_RESTART_ATTEMPTS) {
                    delay(2000) // Wait before next attempt
                }
            }
            
            if (attempts >= MAX_RESTART_ATTEMPTS) {
                Log.e(TAG, "❌ Failed to restart services after $MAX_RESTART_ATTEMPTS attempts")
            }
        }
    }
    
    /**
     * Start main activity to initialize services
     */
    private fun startMainActivity(context: Context, reason: String) {
        try {
            val launchIntent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("restart_reason", reason)
                putExtra("auto_restart", true)
                putExtra("background_start", true)
            }
            
            context.startActivity(launchIntent)
            Log.i(TAG, "Main activity started for service initialization")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error starting main activity", e)
        }
    }
    
    /**
     * Try to start services directly
     */
    private fun startServicesDirectly(context: Context) {
        try {
            // Try to start accessibility service (user must enable manually)
            Log.d(TAG, "Accessibility service requires user action to enable")
            
            // We can't start accessibility service programmatically,
            // but we can ensure our app is ready when it does start
            
        } catch (e: Exception) {
            Log.e(TAG, "Error starting services directly", e)
        }
    }
    
    /**
     * Send broadcast to wake up any sleeping components
     */
    private fun sendWakeupBroadcast(context: Context) {
        try {
            val wakeupIntent = Intent("com.example.surokkha.WAKEUP_SERVICES").apply {
                setPackage(context.packageName)
                putExtra("timestamp", System.currentTimeMillis())
                putExtra("source", "boot_receiver")
            }
            
            context.sendBroadcast(wakeupIntent)
            Log.d(TAG, "Wakeup broadcast sent")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error sending wakeup broadcast", e)
        }
    }
}
