package com.example.surokkha

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import androidx.annotation.RequiresApi
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*

/**
 * Health Check Handler for Android 10+ compatibility
 * Manages battery optimization, background restrictions, and service persistence
 */
class HealthCheckHandler(private val context: Context) : MethodChannel.MethodCallHandler {
    
    companion object {
        private const val TAG = "HealthCheckHandler"
        private const val CHANNEL = "com.example.surokkha/health_check"
    }
    
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val packageManager = context.packageManager
    
    private var healthCheckJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "initializeHealthCheck" -> initializeHealthCheck(result)
            "requestBatteryOptimizationExemption" -> requestBatteryOptimizationExemption(result)
            "setupBackgroundPermissions" -> setupBackgroundPermissions(result)
            "checkBootReceiverStatus" -> checkBootReceiverStatus(result)
            "isBatteryOptimizationDisabled" -> isBatteryOptimizationDisabled(result)
            "repairServices" -> repairServices(result)
            "emergencyServiceRestart" -> emergencyServiceRestart(result)
            "checkServiceHealth" -> checkServiceHealth(result)
            else -> result.notImplemented()
        }
    }
    
    /**
     * Initialize health check system for Android 10+
     */
    private fun initializeHealthCheck(result: MethodChannel.Result) {
        try {
            Log.d(TAG, "Initializing health check system...")
            
            // Start continuous health monitoring
            startContinuousHealthCheck()
            
            // Configure for Android 10+ background restrictions
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                configureAndroid10PlusRestrictions()
            }
            
            result.success(true)
            Log.d(TAG, "Health check system initialized successfully")
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize health check: ${e.message}", e)
            result.success(false)
        }
    }
    
    /**
     * Request battery optimization exemption for persistent operation
     */
    private fun requestBatteryOptimizationExemption(result: MethodChannel.Result) {
        try {
            val packageName = context.packageName
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                    Log.d(TAG, "Requesting battery optimization exemption...")
                    
                    val intent = Intent().apply {
                        action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
                        data = Uri.parse("package:$packageName")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    
                    try {
                        context.startActivity(intent)
                        result.success(true)
                    } catch (e: Exception) {
                        // Fallback to general battery optimization settings
                        val fallbackIntent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(fallbackIntent)
                        result.success(true)
                    }
                } else {
                    Log.d(TAG, "Battery optimization already disabled")
                    result.success(true)
                }
            } else {
                result.success(true) // Not needed for older Android versions
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting battery optimization exemption: ${e.message}", e)
            result.success(false)
        }
    }
    
    /**
     * Setup background permissions for Android 10+
     */
    private fun setupBackgroundPermissions(result: MethodChannel.Result) {
        try {
            Log.d(TAG, "Setting up background permissions...")
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Configure background activity starts
                configureBackgroundActivityStarts()
                
                // Setup background location if needed
                setupBackgroundLocationPermissions()
                
                // Configure app standby bucket
                optimizeAppStandbyBucket()
            }
            
            result.success(true)
            Log.d(TAG, "Background permissions configured")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up background permissions: ${e.message}", e)
            result.success(false)
        }
    }
    
    /**
     * Check boot receiver status
     */
    private fun checkBootReceiverStatus(result: MethodChannel.Result) {
        try {
            val component = android.content.ComponentName(context, BootReceiver::class.java)
            val status = packageManager.getComponentEnabledSetting(component)
            
            val isEnabled = status == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                           status == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT
            
            Log.d(TAG, "Boot receiver status: $isEnabled")
            result.success(isEnabled)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error checking boot receiver status: ${e.message}", e)
            result.success(false)
        }
    }
    
    /**
     * Check if battery optimization is disabled
     */
    private fun isBatteryOptimizationDisabled(result: MethodChannel.Result) {
        try {
            val isDisabled = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                powerManager.isIgnoringBatteryOptimizations(context.packageName)
            } else {
                true // Not applicable for older versions
            }
            
            Log.d(TAG, "Battery optimization disabled: $isDisabled")
            result.success(isDisabled)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error checking battery optimization: ${e.message}", e)
            result.success(false)
        }
    }
    
    /**
     * Repair unhealthy services
     */
    private fun repairServices(result: MethodChannel.Result) {
        scope.launch {
            try {
                Log.d(TAG, "Repairing services...")
                
                // Restart accessibility service
                restartAccessibilityService()
                
                // Restart background service
                restartBackgroundService()
                
                // Re-enable boot receiver
                enableBootReceiver()
                
                // Refresh battery optimization
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    refreshBatteryOptimization()
                }
                
                withContext(Dispatchers.Main) {
                    result.success(true)
                }
                
                Log.d(TAG, "Service repair completed")
                
            } catch (e: Exception) {
                Log.e(TAG, "Error repairing services: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    result.success(false)
                }
            }
        }
    }
    
    /**
     * Emergency service restart for critical failures
     */
    private fun emergencyServiceRestart(result: MethodChannel.Result) {
        scope.launch {
            try {
                Log.w(TAG, "Performing emergency service restart...")
                
                // Force restart all services with delays
                restartAccessibilityService()
                delay(2000)
                
                restartBackgroundService()
                delay(2000)
                
                // Trigger boot receiver manually
                triggerBootReceiver()
                delay(1000)
                
                withContext(Dispatchers.Main) {
                    result.success(true)
                }
                
                Log.d(TAG, "Emergency service restart completed")
                
            } catch (e: Exception) {
                Log.e(TAG, "Emergency service restart failed: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    result.success(false)
                }
            }
        }
    }
    
    /**
     * Check overall service health
     */
    private fun checkServiceHealth(result: MethodChannel.Result) {
        try {
            val healthStatus = mutableMapOf<String, Any>()
            
            // Check accessibility service
            healthStatus["accessibility_service"] = isAccessibilityServiceRunning()
            
            // Check background service
            healthStatus["background_service"] = isBackgroundServiceRunning()
            
            // Check battery optimization
            healthStatus["battery_optimization"] = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                powerManager.isIgnoringBatteryOptimizations(context.packageName)
            } else true
            
            // Check boot receiver
            val component = android.content.ComponentName(context, BootReceiver::class.java)
            val receiverStatus = packageManager.getComponentEnabledSetting(component)
            healthStatus["boot_receiver"] = receiverStatus == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                                          receiverStatus == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT
            
            result.success(healthStatus)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error checking service health: ${e.message}", e)
            result.success(mapOf<String, Any>())
        }
    }
    
    /**
     * Configure Android 10+ specific restrictions
     */
    @RequiresApi(Build.VERSION_CODES.Q)
    private fun configureAndroid10PlusRestrictions() {
        try {
            Log.d(TAG, "Configuring Android 10+ restrictions...")
            
            // Handle background activity launch restrictions
            configureBackgroundActivityStarts()
            
            // Handle app standby buckets
            optimizeAppStandbyBucket()
            
            // Configure foreground service types
            configureForegroundServiceTypes()
            
        } catch (e: Exception) {
            Log.e(TAG, "Error configuring Android 10+ restrictions: ${e.message}", e)
        }
    }
    
    /**
     * Configure background activity starts for Android 10+
     */
    @RequiresApi(Build.VERSION_CODES.Q)
    private fun configureBackgroundActivityStarts() {
        // This is handled through proper foreground service implementation
        // and requesting appropriate permissions in manifest
        Log.d(TAG, "Background activity starts configured")
    }
    
    /**
     * Setup background location permissions if needed
     */
    private fun setupBackgroundLocationPermissions() {
        // Only if location is needed for the app functionality
        Log.d(TAG, "Background location permissions handled")
    }
    
    /**
     * Optimize app standby bucket for better background execution
     */
    private fun optimizeAppStandbyBucket() {
        try {
            // Request user to whitelist the app from battery optimization
            // This helps with app standby bucket optimization
            Log.d(TAG, "App standby bucket optimization requested")
        } catch (e: Exception) {
            Log.e(TAG, "Error optimizing app standby bucket: ${e.message}", e)
        }
    }
    
    /**
     * Configure foreground service types for Android 10+
     */
    private fun configureForegroundServiceTypes() {
        // Handled in AndroidManifest.xml with proper foregroundServiceType
        Log.d(TAG, "Foreground service types configured")
    }
    
    /**
     * Start continuous health monitoring
     */
    private fun startContinuousHealthCheck() {
        healthCheckJob?.cancel()
        healthCheckJob = scope.launch {
            while (isActive) {
                try {
                    performNativeHealthCheck()
                    delay(30000) // Check every 30 seconds
                } catch (e: Exception) {
                    Log.e(TAG, "Error in continuous health check: ${e.message}", e)
                    delay(60000) // Wait longer on error
                }
            }
        }
    }
    
    /**
     * Perform native health check
     */
    private suspend fun performNativeHealthCheck() {
        try {
            // Check if services are running
            if (!isAccessibilityServiceRunning()) {
                Log.w(TAG, "Accessibility service not running - attempting restart")
                restartAccessibilityService()
            }
            
            if (!isBackgroundServiceRunning()) {
                Log.w(TAG, "Background service not running - attempting restart")
                restartBackgroundService()
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error in native health check: ${e.message}", e)
        }
    }
    
    /**
     * Check if accessibility service is running
     */
    private fun isAccessibilityServiceRunning(): Boolean {
        return AccessibilityUtils.isAccessibilityServiceEnabled(context)
    }
    
    /**
     * Check if background service is running
     */
    private fun isBackgroundServiceRunning(): Boolean {
        try {
            val runningServices = activityManager.getRunningServices(Integer.MAX_VALUE)
            return runningServices.any { 
                it.service.className.contains("FlutterForegroundService") ||
                it.service.className.contains("BackgroundService")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking background service: ${e.message}", e)
            return false
        }
    }
    
    /**
     * Restart accessibility service
     */
    private fun restartAccessibilityService() {
        try {
            // Accessibility service restart is handled by the system
            // We can only guide user to settings if needed
            Log.d(TAG, "Accessibility service restart requested")
        } catch (e: Exception) {
            Log.e(TAG, "Error restarting accessibility service: ${e.message}", e)
        }
    }
    
    /**
     * Restart background service
     */
    private fun restartBackgroundService() {
        try {
            // This will be handled by Flutter's foreground task plugin
            Log.d(TAG, "Background service restart requested")
        } catch (e: Exception) {
            Log.e(TAG, "Error restarting background service: ${e.message}", e)
        }
    }
    
    /**
     * Enable boot receiver
     */
    private fun enableBootReceiver() {
        try {
            val component = android.content.ComponentName(context, BootReceiver::class.java)
            packageManager.setComponentEnabledSetting(
                component,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            Log.d(TAG, "Boot receiver enabled")
        } catch (e: Exception) {
            Log.e(TAG, "Error enabling boot receiver: ${e.message}", e)
        }
    }
    
    /**
     * Refresh battery optimization status
     */
    @RequiresApi(Build.VERSION_CODES.M)
    private fun refreshBatteryOptimization() {
        try {
            if (!powerManager.isIgnoringBatteryOptimizations(context.packageName)) {
                Log.w(TAG, "Battery optimization not disabled - user intervention may be needed")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing battery optimization: ${e.message}", e)
        }
    }
    
    /**
     * Trigger boot receiver manually
     */
    private fun triggerBootReceiver() {
        try {
            val intent = Intent(context, BootReceiver::class.java).apply {
                action = Intent.ACTION_BOOT_COMPLETED
            }
            context.sendBroadcast(intent)
            Log.d(TAG, "Boot receiver triggered manually")
        } catch (e: Exception) {
            Log.e(TAG, "Error triggering boot receiver: ${e.message}", e)
        }
    }
    
    /**
     * Cleanup resources
     */
    fun dispose() {
        healthCheckJob?.cancel()
        scope.cancel()
        Log.d(TAG, "Health check handler disposed")
    }
}
