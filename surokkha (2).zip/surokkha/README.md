# Surokkha - Firebase Web Application

A modern web application with comprehensive Firebase integration including Authentication, Firestore Database, and Cloud Storage.

## Features

- 🔐 **Firebase Authentication**
  - Email/Password authentication
  - Google Sign-in
  - Password reset functionality
  - User profile management

- 📊 **Firestore Database**
  - Real-time data synchronization
  - User-specific data storage
  - CRUD operations
  - Security rules implementation

- 📁 **Cloud Storage**
  - File upload with progress tracking
  - Image storage and retrieval
  - User-specific file organization
  - Secure file access

- 🎨 **Modern UI**
  - Responsive design
  - Beautiful gradient backgrounds
  - Smooth animations
  - Mobile-friendly interface

## Setup Instructions

### 1. Firebase Project Setup

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select an existing one
3. Enable Authentication, Firestore, and Storage services
4. Get your Firebase configuration from Project Settings

### 2. Environment Configuration

1. Copy `.env.example` to `.env`
2. Replace the placeholder values with your actual Firebase configuration:

```env
FIREBASE_API_KEY=your-actual-api-key
FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_STORAGE_BUCKET=your-project.appspot.com
FIREBASE_MESSAGING_SENDER_ID=123456789
FIREBASE_APP_ID=1:123456789:web:abcdef123456
FIREBASE_MEASUREMENT_ID=G-XXXXXXXXXX
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Run the Application

For development with Node.js server:
```bash
npm start
```

For development with live reload:
```bash
npm run dev
```

The application will be available at `http://localhost:3000`

### 5. Firebase CLI Setup (Optional)

For deployment and advanced features:

```bash
# Install Firebase CLI globally
npm install -g firebase-tools

# Login to Firebase
firebase login

# Initialize Firebase in your project
firebase init

# Deploy to Firebase Hosting
npm run deploy
```

## Project Structure

```
surokkha/
├── index.html              # Main HTML file
├── styles.css              # Application styles
├── app.js                  # Main application logic
├── firebase-config.js      # Firebase configuration
├── server.js               # Express server
├── package.json            # Dependencies and scripts
├── firebase.json           # Firebase project configuration
├── firestore.rules         # Firestore security rules
├── storage.rules           # Storage security rules
├── firestore.indexes.json  # Firestore indexes
├── services/
│   ├── auth.js            # Authentication service
│   ├── firestore.js       # Firestore service
│   └── storage.js         # Storage service
└── README.md              # This file
```

## Services Overview

### Authentication Service (`services/auth.js`)
- User registration and login
- Google authentication
- Password reset
- Auth state management

### Firestore Service (`services/firestore.js`)
- CRUD operations
- Real-time data synchronization
- Query functionality
- Collection management

### Storage Service (`services/storage.js`)
- File upload with progress tracking
- File deletion
- URL generation
- Metadata management

## Security

The application implements proper security rules:

- **Firestore Rules**: Users can only access their own data
- **Storage Rules**: Users can only upload/access files in their directory
- **Authentication**: All operations require user authentication

## Development

### Adding New Features

1. Create new service files in the `services/` directory
2. Import and use services in `app.js`
3. Update UI components in `index.html` and `styles.css`
4. Test thoroughly before deployment

### Debugging

- Check browser console for errors
- Verify Firebase configuration
- Ensure proper authentication state
- Check network requests in DevTools

## Deployment

### Firebase Hosting

```bash
firebase deploy
```

### Custom Server

Deploy `server.js` to your preferred hosting platform (Heroku, Vercel, etc.)

## Support

For issues and questions:
1. Check the Firebase documentation
2. Review browser console errors
3. Verify Firebase project configuration
4. Ensure all dependencies are installed

## License

MIT License - feel free to use this project as a starting point for your own Firebase applications.
