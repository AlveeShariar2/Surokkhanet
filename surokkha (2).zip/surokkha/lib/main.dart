import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'screens/setup_screen.dart';
import 'services/background_service.dart';
import 'services/health_check_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  
  // Initialize background service
  final backgroundService = BackgroundService();
  await backgroundService.initialize();
  
  // Initialize health check service for Android 10+ compatibility
  final healthCheckService = HealthCheckService();
  await healthCheckService.initialize();
  
  runApp(const SurokkhApp());
}

class SurokkhApp extends StatelessWidget {
  const SurokkhApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Surokkha',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6366F1),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          filled: true,
          fillColor: Colors.grey.shade50,
        ),
      ),
      home: const SetupScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
