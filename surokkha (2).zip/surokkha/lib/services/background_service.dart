import 'dart:async';
import 'dart:isolate';
import 'package:flutter/foundation.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import '../firebase_options.dart';

class BackgroundService {
  static final BackgroundService _instance = BackgroundService._internal();
  factory BackgroundService() => _instance;
  BackgroundService._internal();

  static const String _taskId = 'surokkha_background_service';
  bool _isServiceRunning = false;

  /// Initialize and start the background service
  Future<bool> startService() async {
    if (_isServiceRunning) {
      debugPrint('Background service is already running');
      return true;
    }

    try {
      // Initialize foreground task
      FlutterForegroundTask.init(
        androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'surokkha_foreground_service',
          channelName: 'Surokkha Security Service',
          channelDescription: 'This notification appears when Surokkha security service is running in the background.',
          channelImportance: NotificationChannelImportance.LOW,
          priority: NotificationPriority.LOW,
          iconData: const NotificationIconData(
            resType: ResourceType.mipmap,
            resPrefix: ResourcePrefix.ic,
            name: 'launcher',
          ),
          buttons: [
            const NotificationButton(id: 'btn_stop', text: 'Stop Service'),
          ],
        ),
        iosNotificationOptions: const IOSNotificationOptions(
          showNotification: true,
          playSound: false,
        ),
        foregroundTaskOptions: const ForegroundTaskOptions(
          interval: 30000, // 30 seconds
          isOnceEvent: false,
          autoRunOnBoot: true,
          allowWakeLock: true,
          allowWifiLock: true,
        ),
      );

      // Start the foreground service
      final serviceId = await FlutterForegroundTask.startService(
        notificationTitle: 'Surokkha Security Active',
        notificationText: 'Monitoring device security and maintaining Firebase connection',
        callback: startBackgroundTask,
      );

      if (serviceId != null) {
        _isServiceRunning = true;
        debugPrint('✅ Background service started with ID: $serviceId');
        return true;
      } else {
        debugPrint('❌ Failed to start background service');
        return false;
      }
    } catch (e) {
      debugPrint('❌ Error starting background service: $e');
      return false;
    }
  }

  /// Stop the background service
  Future<bool> stopService() async {
    try {
      await FlutterForegroundTask.stopService();
      _isServiceRunning = false;
      debugPrint('✅ Background service stopped');
      return true;
    } catch (e) {
      debugPrint('❌ Error stopping background service: $e');
      return false;
    }
  }

  /// Check if service is running
  bool get isServiceRunning => _isServiceRunning;

  /// Update service notification
  Future<void> updateNotification({
    String? title,
    String? text,
  }) async {
    if (_isServiceRunning) {
      await FlutterForegroundTask.updateService(
        notificationTitle: title ?? 'Surokkha Security Active',
        notificationText: text ?? 'Monitoring device security and maintaining Firebase connection',
      );
    }
  }

  /// Request permissions for background service
  Future<bool> requestPermissions() async {
    try {
      // Request notification permission
      final NotificationPermission notificationPermissionStatus =
          await FlutterForegroundTask.checkNotificationPermission();
      
      if (notificationPermissionStatus != NotificationPermission.granted) {
        final NotificationPermission requestResult =
            await FlutterForegroundTask.requestNotificationPermission();
        
        if (requestResult != NotificationPermission.granted) {
          debugPrint('❌ Notification permission denied');
          return false;
        }
      }

      // Request ignore battery optimization (Android)
      if (!kIsWeb) {
        final bool batteryOptimizationStatus =
            await FlutterForegroundTask.isIgnoringBatteryOptimizations();
        
        if (!batteryOptimizationStatus) {
          final bool requestResult =
              await FlutterForegroundTask.requestIgnoreBatteryOptimization();
          
          if (!requestResult) {
            debugPrint('⚠️ Battery optimization not disabled - service may be killed');
          }
        }
      }

      debugPrint('✅ Background service permissions granted');
      return true;
    } catch (e) {
      debugPrint('❌ Error requesting permissions: $e');
      return false;
    }
  }
}

/// Background task callback function
@pragma('vm:entry-point')
void startBackgroundTask() {
  FlutterForegroundTask.setTaskHandler(SurokkhBackgroundTaskHandler());
}

/// Background task handler
class SurokkhBackgroundTaskHandler extends TaskHandler {
  late DatabaseReference _database;
  String? _deviceId;
  int _executionCount = 0;
  Timer? _heartbeatTimer;

  @override
  Future<void> onStart(DateTime timestamp, SendPort? sendPort) async {
    debugPrint('🚀 Background task started at: $timestamp');
    
    try {
      // Initialize Firebase in background isolate
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
      
      _database = FirebaseDatabase.instance.ref();
      _deviceId = await _generateDeviceId();
      
      // Start heartbeat timer
      _startHeartbeat();
      
      debugPrint('✅ Background task initialized successfully');
    } catch (e) {
      debugPrint('❌ Error initializing background task: $e');
    }
  }

  @override
  Future<void> onEvent(DateTime timestamp, SendPort? sendPort) async {
    _executionCount++;
    
    try {
      // Update device status in Firebase
      await _updateDeviceStatus();
      
      // Perform security checks
      await _performSecurityChecks();
      
      // Update notification with current status
      await FlutterForegroundTask.updateService(
        notificationTitle: 'Surokkha Security Active',
        notificationText: 'Last check: ${timestamp.toString().substring(11, 19)} | Executions: $_executionCount',
      );
      
      debugPrint('📊 Background task executed #$_executionCount at: $timestamp');
    } catch (e) {
      debugPrint('❌ Error in background task execution: $e');
    }
  }

  @override
  Future<void> onDestroy(DateTime timestamp, SendPort? sendPort) async {
    debugPrint('🛑 Background task destroyed at: $timestamp');
    
    try {
      // Cancel heartbeat timer
      _heartbeatTimer?.cancel();
      
      // Update device status to offline
      if (_deviceId != null) {
        await _database.child('devices').child(_deviceId!).update({
          'status': 'OFFLINE',
          'lastSeen': ServerValue.timestamp,
        });
      }
    } catch (e) {
      debugPrint('❌ Error in background task cleanup: $e');
    }
  }

  @override
  Future<void> onButtonPressed(String id) async {
    debugPrint('🔘 Button pressed: $id');
    
    if (id == 'btn_stop') {
      await FlutterForegroundTask.stopService();
    }
  }

  /// Start heartbeat timer for frequent updates
  void _startHeartbeat() {
    _heartbeatTimer = Timer.periodic(const Duration(minutes: 1), (timer) async {
      try {
        await _sendHeartbeat();
      } catch (e) {
        debugPrint('❌ Heartbeat error: $e');
      }
    });
  }

  /// Send heartbeat to Firebase
  Future<void> _sendHeartbeat() async {
    if (_deviceId == null) return;

    try {
      await _database.child('devices').child(_deviceId!).child('heartbeat').set({
        'timestamp': ServerValue.timestamp,
        'status': 'ALIVE',
        'executionCount': _executionCount,
      });
    } catch (e) {
      debugPrint('❌ Failed to send heartbeat: $e');
    }
  }

  /// Update device status in Firebase
  Future<void> _updateDeviceStatus() async {
    if (_deviceId == null) return;

    try {
      final statusData = {
        'status': 'ACTIVE',
        'lastSeen': ServerValue.timestamp,
        'backgroundService': {
          'isRunning': true,
          'executionCount': _executionCount,
          'lastExecution': ServerValue.timestamp,
        },
        'systemInfo': {
          'timestamp': DateTime.now().toIso8601String(),
          'uptime': _executionCount * 30, // Approximate uptime in seconds
        }
      };

      await _database.child('devices').child(_deviceId!).update(statusData);
    } catch (e) {
      debugPrint('❌ Failed to update device status: $e');
    }
  }

  /// Perform security checks
  Future<void> _performSecurityChecks() async {
    if (_deviceId == null) return;

    try {
      final securityData = {
        'securityChecks': {
          'timestamp': ServerValue.timestamp,
          'checkCount': _executionCount,
          'status': 'SECURE',
          'lastCheck': DateTime.now().toIso8601String(),
        }
      };

      await _database.child('devices').child(_deviceId!).update(securityData);
    } catch (e) {
      debugPrint('❌ Failed to perform security checks: $e');
    }
  }

  /// Generate device ID
  Future<String> _generateDeviceId() async {
    // Use a simple device ID generation for background task
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return 'BG_SERVICE_${timestamp}_${_executionCount}';
  }
}

/// Extension to handle background service lifecycle
extension BackgroundServiceExtension on BackgroundService {
  /// Initialize service with permissions and auto-start
  Future<bool> initializeAndStart() async {
    try {
      // Request necessary permissions
      final permissionsGranted = await requestPermissions();
      if (!permissionsGranted) {
        debugPrint('❌ Required permissions not granted');
        return false;
      }

      // Start the service
      final serviceStarted = await startService();
      if (!serviceStarted) {
        debugPrint('❌ Failed to start background service');
        return false;
      }

      debugPrint('✅ Background service initialized and started successfully');
      return true;
    } catch (e) {
      debugPrint('❌ Error initializing background service: $e');
      return false;
    }
  }

  /// Restart service if it's not running
  Future<bool> ensureServiceRunning() async {
    if (!isServiceRunning) {
      debugPrint('🔄 Service not running, attempting to restart...');
      return await initializeAndStart();
    }
    return true;
  }
}
