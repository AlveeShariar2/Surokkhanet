import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'dart:io';

class FirebaseService {
  static final FirebaseService _instance = FirebaseService._internal();
  factory FirebaseService() => _instance;
  FirebaseService._internal();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // Auth methods
  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<UserCredential> signInWithEmailAndPassword(String email, String password) async {
    try {
      return await _auth.signInWithEmailAndPassword(email: email, password: password);
    } catch (e) {
      debugPrint('Sign in error: $e');
      rethrow;
    }
  }

  Future<UserCredential> createUserWithEmailAndPassword(String email, String password) async {
    try {
      return await _auth.createUserWithEmailAndPassword(email: email, password: password);
    } catch (e) {
      debugPrint('Sign up error: $e');
      rethrow;
    }
  }

  Future<void> signOut() async {
    try {
      await _auth.signOut();
    } catch (e) {
      debugPrint('Sign out error: $e');
      rethrow;
    }
  }

  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      debugPrint('Password reset error: $e');
      rethrow;
    }
  }

  // Firestore methods
  Future<DocumentReference> addDocument(String collection, Map<String, dynamic> data) async {
    try {
      data['createdAt'] = FieldValue.serverTimestamp();
      data['updatedAt'] = FieldValue.serverTimestamp();
      return await _firestore.collection(collection).add(data);
    } catch (e) {
      debugPrint('Add document error: $e');
      rethrow;
    }
  }

  Future<DocumentSnapshot> getDocument(String collection, String documentId) async {
    try {
      return await _firestore.collection(collection).doc(documentId).get();
    } catch (e) {
      debugPrint('Get document error: $e');
      rethrow;
    }
  }

  Future<QuerySnapshot> getCollection(String collection, {
    String? orderBy,
    bool descending = false,
    int? limit,
    List<QueryFilter>? filters,
  }) async {
    try {
      Query query = _firestore.collection(collection);
      
      if (filters != null) {
        for (var filter in filters) {
          query = query.where(filter.field, isEqualTo: filter.value);
        }
      }
      
      if (orderBy != null) {
        query = query.orderBy(orderBy, descending: descending);
      }
      
      if (limit != null) {
        query = query.limit(limit);
      }
      
      return await query.get();
    } catch (e) {
      debugPrint('Get collection error: $e');
      rethrow;
    }
  }

  Future<void> updateDocument(String collection, String documentId, Map<String, dynamic> data) async {
    try {
      data['updatedAt'] = FieldValue.serverTimestamp();
      await _firestore.collection(collection).doc(documentId).update(data);
    } catch (e) {
      debugPrint('Update document error: $e');
      rethrow;
    }
  }

  Future<void> deleteDocument(String collection, String documentId) async {
    try {
      await _firestore.collection(collection).doc(documentId).delete();
    } catch (e) {
      debugPrint('Delete document error: $e');
      rethrow;
    }
  }

  Stream<QuerySnapshot> streamCollection(String collection, {
    String? orderBy,
    bool descending = false,
    int? limit,
    List<QueryFilter>? filters,
  }) {
    try {
      Query query = _firestore.collection(collection);
      
      if (filters != null) {
        for (var filter in filters) {
          query = query.where(filter.field, isEqualTo: filter.value);
        }
      }
      
      if (orderBy != null) {
        query = query.orderBy(orderBy, descending: descending);
      }
      
      if (limit != null) {
        query = query.limit(limit);
      }
      
      return query.snapshots();
    } catch (e) {
      debugPrint('Stream collection error: $e');
      rethrow;
    }
  }

  // Storage methods
  Future<String> uploadFile(File file, String path) async {
    try {
      final ref = _storage.ref().child(path);
      final uploadTask = ref.putFile(file);
      final snapshot = await uploadTask;
      return await snapshot.ref.getDownloadURL();
    } catch (e) {
      debugPrint('Upload file error: $e');
      rethrow;
    }
  }

  Future<String> uploadFileWithProgress(
    File file, 
    String path, 
    Function(double)? onProgress,
  ) async {
    try {
      final ref = _storage.ref().child(path);
      final uploadTask = ref.putFile(file);
      
      uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
        double progress = snapshot.bytesTransferred / snapshot.totalBytes;
        onProgress?.call(progress);
      });
      
      final snapshot = await uploadTask;
      return await snapshot.ref.getDownloadURL();
    } catch (e) {
      debugPrint('Upload file with progress error: $e');
      rethrow;
    }
  }

  Future<void> deleteFile(String path) async {
    try {
      await _storage.ref().child(path).delete();
    } catch (e) {
      debugPrint('Delete file error: $e');
      rethrow;
    }
  }

  Future<ListResult> listFiles(String path) async {
    try {
      return await _storage.ref().child(path).listAll();
    } catch (e) {
      debugPrint('List files error: $e');
      rethrow;
    }
  }

  String generateFilePath(String userId, String category, String fileName) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final cleanFileName = fileName.replaceAll(RegExp(r'[^a-zA-Z0-9.-]'), '_');
    return 'users/$userId/$category/${timestamp}_$cleanFileName';
  }
}

class QueryFilter {
  final String field;
  final dynamic value;

  QueryFilter({required this.field, required this.value});
}
