import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'dart:io';
import 'dart:convert';
import 'dart:math';

class DeviceSecurityService {
  static final DeviceSecurityService _instance = DeviceSecurityService._internal();
  factory DeviceSecurityService() => _instance;
  DeviceSecurityService._internal();

  static const MethodChannel _channel = MethodChannel('device_security');

  // Security status tracking
  bool _isInitialized = false;
  String? _deviceFingerprint;
  Map<String, dynamic>? _securityFeatures;

  /// Initialize the device security service
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      await _generateDeviceFingerprint();
      await _checkSecurityFeatures();
      _isInitialized = true;
      debugPrint('✅ Device Security Service initialized');
    } catch (e) {
      debugPrint('❌ Failed to initialize Device Security Service: $e');
      rethrow;
    }
  }

  /// Generate a unique device fingerprint
  Future<void> _generateDeviceFingerprint() async {
    try {
      final deviceInfo = await _getDeviceInfo();
      final fingerprintData = {
        'platform': Platform.operatingSystem,
        'version': Platform.operatingSystemVersion,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'random': _generateRandomString(16),
        ...deviceInfo,
      };

      final fingerprintString = json.encode(fingerprintData);
      _deviceFingerprint = _hashString(fingerprintString);
      
      debugPrint('Device fingerprint generated: ${_deviceFingerprint?.substring(0, 8)}...');
    } catch (e) {
      debugPrint('Error generating device fingerprint: $e');
      throw Exception('Failed to generate device fingerprint');
    }
  }

  /// Get basic device information
  Future<Map<String, dynamic>> _getDeviceInfo() async {
    return {
      'isPhysicalDevice': !kIsWeb && (Platform.isAndroid || Platform.isIOS),
      'platform': Platform.operatingSystem,
      'version': Platform.operatingSystemVersion,
      'locale': Platform.localeName,
      'numberOfProcessors': Platform.numberOfProcessors,
    };
  }

  /// Check available security features
  Future<void> _checkSecurityFeatures() async {
    _securityFeatures = {
      'biometric': await isBiometricAvailable(),
      'secureStorage': await isSecureStorageAvailable(),
      'networkSecurity': await isNetworkSecurityAvailable(),
      'encryption': true, // Always available in Flutter
      'deviceLock': await isDeviceLockEnabled(),
    };
  }

  /// Check if biometric authentication is available
  Future<bool> isBiometricAvailable() async {
    try {
      if (kIsWeb) return false;
      
      // Simulate biometric check - in real app, use local_auth package
      if (Platform.isAndroid || Platform.isIOS) {
        return true; // Assume modern devices have biometric capability
      }
      return false;
    } catch (e) {
      debugPrint('Error checking biometric availability: $e');
      return false;
    }
  }

  /// Check if secure storage is available
  Future<bool> isSecureStorageAvailable() async {
    try {
      // Secure storage is generally available on all platforms
      return true;
    } catch (e) {
      debugPrint('Error checking secure storage: $e');
      return false;
    }
  }

  /// Check if network security features are available
  Future<bool> isNetworkSecurityAvailable() async {
    try {
      // Network security is available through Flutter's HTTP client
      return true;
    } catch (e) {
      debugPrint('Error checking network security: $e');
      return false;
    }
  }

  /// Check if device lock is enabled
  Future<bool> isDeviceLockEnabled() async {
    try {
      if (kIsWeb) return false;
      
      // Simulate device lock check - in real app, check system settings
      return true; // Assume device has lock enabled
    } catch (e) {
      debugPrint('Error checking device lock: $e');
      return false;
    }
  }

  /// Get security level based on available features
  String getSecurityLevel() {
    if (_securityFeatures == null) return 'UNKNOWN';

    int securityScore = 0;
    if (_securityFeatures!['biometric'] == true) securityScore += 2;
    if (_securityFeatures!['secureStorage'] == true) securityScore += 2;
    if (_securityFeatures!['networkSecurity'] == true) securityScore += 1;
    if (_securityFeatures!['encryption'] == true) securityScore += 2;
    if (_securityFeatures!['deviceLock'] == true) securityScore += 1;

    if (securityScore >= 7) return 'HIGH';
    if (securityScore >= 5) return 'MEDIUM';
    if (securityScore >= 3) return 'LOW';
    return 'MINIMAL';
  }

  /// Get device fingerprint
  String? get deviceFingerprint => _deviceFingerprint;

  /// Get security features
  Map<String, dynamic>? get securityFeatures => _securityFeatures;

  /// Check if service is initialized
  bool get isInitialized => _isInitialized;

  /// Generate a random string
  String _generateRandomString(int length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final random = Random.secure();
    return List.generate(length, (index) => chars[random.nextInt(chars.length)]).join();
  }

  /// Simple hash function for fingerprinting
  String _hashString(String input) {
    int hash = 0;
    for (int i = 0; i < input.length; i++) {
      hash = ((hash << 5) - hash + input.codeUnitAt(i)) & 0xFFFFFFFF;
    }
    return hash.abs().toRadixString(16).padLeft(8, '0').toUpperCase();
  }

  /// Validate device integrity
  Future<bool> validateDeviceIntegrity() async {
    try {
      if (!_isInitialized) {
        await initialize();
      }

      // Perform various security checks
      final checks = [
        await _checkRootJailbreak(),
        await _checkDebugMode(),
        await _checkEmulator(),
        await _checkTampering(),
      ];

      // Return true if all checks pass
      return checks.every((check) => check);
    } catch (e) {
      debugPrint('Error validating device integrity: $e');
      return false;
    }
  }

  /// Check for root/jailbreak
  Future<bool> _checkRootJailbreak() async {
    try {
      if (kIsWeb) return true;
      
      // Simulate root/jailbreak detection
      // In real implementation, check for common root/jailbreak indicators
      return true; // Assume device is not rooted/jailbroken
    } catch (e) {
      return false;
    }
  }

  /// Check for debug mode
  Future<bool> _checkDebugMode() async {
    try {
      // In release mode, kDebugMode should be false
      return !kDebugMode;
    } catch (e) {
      return false;
    }
  }

  /// Check if running on emulator
  Future<bool> _checkEmulator() async {
    try {
      if (kIsWeb) return true;
      
      // Simulate emulator detection
      // In real implementation, check device characteristics
      return true; // Assume running on real device
    } catch (e) {
      return false;
    }
  }

  /// Check for app tampering
  Future<bool> _checkTampering() async {
    try {
      // Simulate tampering detection
      // In real implementation, check app signature, file integrity, etc.
      return true; // Assume app is not tampered
    } catch (e) {
      return false;
    }
  }

  /// Get comprehensive security report
  Future<Map<String, dynamic>> getSecurityReport() async {
    if (!_isInitialized) {
      await initialize();
    }

    return {
      'deviceFingerprint': _deviceFingerprint,
      'securityLevel': getSecurityLevel(),
      'securityFeatures': _securityFeatures,
      'deviceIntegrity': await validateDeviceIntegrity(),
      'timestamp': DateTime.now().toIso8601String(),
      'platform': Platform.operatingSystem,
      'version': Platform.operatingSystemVersion,
    };
  }
}
