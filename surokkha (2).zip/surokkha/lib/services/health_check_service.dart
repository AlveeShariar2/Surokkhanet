import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import 'device_security_service.dart';
import 'accessibility_bridge.dart';
import 'background_service.dart';

/// Health Check Service for persistent monitoring across Android versions
/// Ensures services remain active on Android 10+ with background restrictions
class HealthCheckService {
  static final HealthCheckService _instance = HealthCheckService._internal();
  factory HealthCheckService() => _instance;
  HealthCheckService._internal();

  static const MethodChannel _channel = MethodChannel('com.example.surokkha/health_check');
  
  Timer? _healthCheckTimer;
  Timer? _deepHealthTimer;
  bool _isInitialized = false;
  bool _isHealthy = true;
  
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  String? _deviceId;
  
  // Health check intervals
  static const Duration _quickCheckInterval = Duration(minutes: 2);
  static const Duration _deepCheckInterval = Duration(minutes: 10);
  static const Duration _emergencyCheckInterval = Duration(seconds: 30);
  
  // Service status tracking
  Map<String, bool> _serviceStatus = {
    'firebase': false,
    'background_service': false,
    'accessibility_service': false,
    'boot_receiver': false,
    'battery_optimization': false,
  };

  /// Initialize health check service
  Future<bool> initialize() async {
    if (_isInitialized) return true;
    
    try {
      debugPrint('🏥 Initializing Health Check Service...');
      
      // Get device ID
      final deviceSecurity = DeviceSecurityService();
      _deviceId = await deviceSecurity.getDeviceId();
      
      // Initialize native health check components
      await _initializeNativeHealthCheck();
      
      // Start health monitoring
      await _startHealthMonitoring();
      
      _isInitialized = true;
      debugPrint('✅ Health Check Service initialized successfully');
      return true;
      
    } catch (e) {
      debugPrint('❌ Failed to initialize Health Check Service: $e');
      return false;
    }
  }

  /// Initialize native health check components for Android 10+
  Future<void> _initializeNativeHealthCheck() async {
    try {
      if (Platform.isAndroid) {
        // Request battery optimization exemption
        await _requestBatteryOptimizationExemption();
        
        // Setup background app refresh permissions
        await _setupBackgroundPermissions();
        
        // Initialize native health monitoring
        await _channel.invokeMethod('initializeHealthCheck');
        
        debugPrint('✅ Native health check components initialized');
      }
    } catch (e) {
      debugPrint('❌ Error initializing native health check: $e');
    }
  }

  /// Request battery optimization exemption for Android 10+
  Future<void> _requestBatteryOptimizationExemption() async {
    try {
      final result = await _channel.invokeMethod('requestBatteryOptimizationExemption');
      _serviceStatus['battery_optimization'] = result ?? false;
      
      if (_serviceStatus['battery_optimization']!) {
        debugPrint('✅ Battery optimization exemption granted');
      } else {
        debugPrint('⚠️ Battery optimization exemption not granted');
      }
    } catch (e) {
      debugPrint('❌ Error requesting battery optimization exemption: $e');
    }
  }

  /// Setup background permissions for Android 10+
  Future<void> _setupBackgroundPermissions() async {
    try {
      await _channel.invokeMethod('setupBackgroundPermissions');
      debugPrint('✅ Background permissions configured');
    } catch (e) {
      debugPrint('❌ Error setting up background permissions: $e');
    }
  }

  /// Start comprehensive health monitoring
  Future<void> _startHealthMonitoring() async {
    try {
      // Quick health checks every 2 minutes
      _healthCheckTimer = Timer.periodic(_quickCheckInterval, (_) => _performQuickHealthCheck());
      
      // Deep health checks every 10 minutes
      _deepHealthTimer = Timer.periodic(_deepCheckInterval, (_) => _performDeepHealthCheck());
      
      // Perform initial health check
      await _performDeepHealthCheck();
      
      debugPrint('✅ Health monitoring started');
    } catch (e) {
      debugPrint('❌ Error starting health monitoring: $e');
    }
  }

  /// Perform quick health check
  Future<void> _performQuickHealthCheck() async {
    try {
      // Check Firebase connection
      _serviceStatus['firebase'] = await _checkFirebaseHealth();
      
      // Check background service
      _serviceStatus['background_service'] = await _checkBackgroundServiceHealth();
      
      // Update overall health status
      _updateHealthStatus();
      
      // Log quick health check
      await _logHealthStatus('quick_check');
      
    } catch (e) {
      debugPrint('❌ Error in quick health check: $e');
      _isHealthy = false;
    }
  }

  /// Perform comprehensive deep health check
  Future<void> _performDeepHealthCheck() async {
    try {
      debugPrint('🔍 Performing deep health check...');
      
      // Check all services
      _serviceStatus['firebase'] = await _checkFirebaseHealth();
      _serviceStatus['background_service'] = await _checkBackgroundServiceHealth();
      _serviceStatus['accessibility_service'] = await _checkAccessibilityServiceHealth();
      _serviceStatus['boot_receiver'] = await _checkBootReceiverHealth();
      _serviceStatus['battery_optimization'] = await _checkBatteryOptimizationStatus();
      
      // Update health status
      _updateHealthStatus();
      
      // Attempt to repair unhealthy services
      if (!_isHealthy) {
        await _repairUnhealthyServices();
      }
      
      // Log comprehensive health status
      await _logHealthStatus('deep_check');
      
      debugPrint('✅ Deep health check completed. Healthy: $_isHealthy');
      
    } catch (e) {
      debugPrint('❌ Error in deep health check: $e');
      _isHealthy = false;
      await _handleHealthCheckFailure();
    }
  }

  /// Check Firebase connection health
  Future<bool> _checkFirebaseHealth() async {
    try {
      // Test Firebase connection
      await _database.child('.info/connected').once();
      return true;
    } catch (e) {
      debugPrint('❌ Firebase health check failed: $e');
      return false;
    }
  }

  /// Check background service health
  Future<bool> _checkBackgroundServiceHealth() async {
    try {
      final backgroundService = BackgroundService();
      return await backgroundService.isServiceRunning();
    } catch (e) {
      debugPrint('❌ Background service health check failed: $e');
      return false;
    }
  }

  /// Check accessibility service health
  Future<bool> _checkAccessibilityServiceHealth() async {
    try {
      final accessibilityBridge = AccessibilityBridge();
      return await accessibilityBridge.isAccessibilityServiceEnabled();
    } catch (e) {
      debugPrint('❌ Accessibility service health check failed: $e');
      return false;
    }
  }

  /// Check boot receiver health
  Future<bool> _checkBootReceiverHealth() async {
    try {
      final result = await _channel.invokeMethod('checkBootReceiverStatus');
      return result ?? false;
    } catch (e) {
      debugPrint('❌ Boot receiver health check failed: $e');
      return false;
    }
  }

  /// Check battery optimization status
  Future<bool> _checkBatteryOptimizationStatus() async {
    try {
      final result = await _channel.invokeMethod('isBatteryOptimizationDisabled');
      return result ?? false;
    } catch (e) {
      debugPrint('❌ Battery optimization check failed: $e');
      return false;
    }
  }

  /// Update overall health status
  void _updateHealthStatus() {
    final criticalServices = ['firebase', 'background_service'];
    _isHealthy = criticalServices.every((service) => _serviceStatus[service] == true);
  }

  /// Repair unhealthy services
  Future<void> _repairUnhealthyServices() async {
    try {
      debugPrint('🔧 Attempting to repair unhealthy services...');
      
      // Restart background service if unhealthy
      if (!_serviceStatus['background_service']!) {
        final backgroundService = BackgroundService();
        await backgroundService.ensureServiceRunning();
      }
      
      // Restart accessibility service if unhealthy
      if (!_serviceStatus['accessibility_service']!) {
        final accessibilityBridge = AccessibilityBridge();
        await accessibilityBridge.ensureServicesRunning();
      }
      
      // Request battery optimization exemption if needed
      if (!_serviceStatus['battery_optimization']!) {
        await _requestBatteryOptimizationExemption();
      }
      
      // Trigger native service repair
      await _channel.invokeMethod('repairServices');
      
      debugPrint('✅ Service repair completed');
      
    } catch (e) {
      debugPrint('❌ Error repairing services: $e');
    }
  }

  /// Handle health check failure
  Future<void> _handleHealthCheckFailure() async {
    try {
      debugPrint('🚨 Health check failure detected - entering emergency mode');
      
      // Switch to emergency check interval
      _healthCheckTimer?.cancel();
      _healthCheckTimer = Timer.periodic(_emergencyCheckInterval, (_) => _performQuickHealthCheck());
      
      // Attempt emergency service restart
      await _emergencyServiceRestart();
      
      // Log emergency status
      await _logHealthStatus('emergency');
      
    } catch (e) {
      debugPrint('❌ Error handling health check failure: $e');
    }
  }

  /// Emergency service restart
  Future<void> _emergencyServiceRestart() async {
    try {
      debugPrint('🚨 Performing emergency service restart...');
      
      // Restart all services
      final backgroundService = BackgroundService();
      await backgroundService.ensureServiceRunning();
      
      final accessibilityBridge = AccessibilityBridge();
      await accessibilityBridge.ensureServicesRunning();
      
      // Trigger native emergency restart
      await _channel.invokeMethod('emergencyServiceRestart');
      
    } catch (e) {
      debugPrint('❌ Emergency service restart failed: $e');
    }
  }

  /// Log health status to Firebase
  Future<void> _logHealthStatus(String checkType) async {
    try {
      if (_deviceId != null) {
        await _database.child('devices').child(_deviceId!).child('health').update({
          'lastCheck': ServerValue.timestamp,
          'checkType': checkType,
          'isHealthy': _isHealthy,
          'services': _serviceStatus,
          'androidVersion': Platform.version,
          'timestamp': DateTime.now().toIso8601String(),
        });
      }
    } catch (e) {
      debugPrint('❌ Error logging health status: $e');
    }
  }

  /// Get current health status
  Map<String, dynamic> getHealthStatus() {
    return {
      'isHealthy': _isHealthy,
      'services': Map.from(_serviceStatus),
      'lastCheck': DateTime.now().toIso8601String(),
    };
  }

  /// Stop health monitoring
  void dispose() {
    _healthCheckTimer?.cancel();
    _deepHealthTimer?.cancel();
    _isInitialized = false;
    debugPrint('🏥 Health Check Service disposed');
  }
}
