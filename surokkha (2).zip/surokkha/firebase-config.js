// Firebase configuration for browser environment
// Import Firebase SDK from CDN (will be loaded via script tags in HTML)

// Your web app's Firebase configuration
// Replace with your actual Firebase config from Firebase Console
const firebaseConfig = {
  apiKey: "your-api-key-here",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456",
  measurementId: "G-XXXXXXXXXX"
};

// Initialize Firebase
let app;
let auth;
let db;
let storage;
let analytics;

// Initialize Firebase services (will be called after Firebase SDK loads)
function initializeFirebase() {
  app = firebase.initializeApp(firebaseConfig);
  auth = firebase.auth();
  db = firebase.firestore();
  storage = firebase.storage();
  analytics = firebase.analytics();
  
  console.log('Firebase initialized successfully');
  return { app, auth, db, storage, analytics };
}

// Export for use in other modules
window.firebaseConfig = firebaseConfig;
window.initializeFirebase = initializeFirebase;
