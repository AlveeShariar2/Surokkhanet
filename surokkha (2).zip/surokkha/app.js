// Main Application File
import authService from './services/auth.js';
import firestoreService from './services/firestore.js';
import storageService from './services/storage.js';

class App {
  constructor() {
    this.user = null;
    this.init();
  }

  async init() {
    // Listen for authentication state changes
    authService.onAuthStateChange((user) => {
      this.user = user;
      this.updateUI();
    });

    // Initialize UI
    this.setupEventListeners();
    this.updateUI();
  }

  setupEventListeners() {
    // Auth UI controls
    const showLoginBtn = document.getElementById('show-login');
    const showRegisterBtn = document.getElementById('show-register');
    const logoutBtn = document.getElementById('logout-btn');
    const googleLoginBtn = document.getElementById('google-login');
    
    // Auth forms
    const loginForm = document.getElementById('login');
    const registerForm = document.getElementById('register');
    
    // App functionality
    const addDataBtn = document.getElementById('add-data');
    const uploadFileBtn = document.getElementById('upload-file');
    const fileInput = document.getElementById('file-input');

    // Show/hide forms
    if (showLoginBtn) {
      showLoginBtn.addEventListener('click', () => this.showForm('login'));
    }
    if (showRegisterBtn) {
      showRegisterBtn.addEventListener('click', () => this.showForm('register'));
    }

    // Auth actions
    if (loginForm) {
      loginForm.addEventListener('submit', this.handleLogin.bind(this));
    }
    if (registerForm) {
      registerForm.addEventListener('submit', this.handleRegister.bind(this));
    }
    if (logoutBtn) {
      logoutBtn.addEventListener('click', this.handleLogout.bind(this));
    }
    if (googleLoginBtn) {
      googleLoginBtn.addEventListener('click', this.handleGoogleLogin.bind(this));
    }

    // App functionality
    if (addDataBtn) {
      addDataBtn.addEventListener('click', this.handleAddData.bind(this));
    }
    if (uploadFileBtn) {
      uploadFileBtn.addEventListener('click', this.handleFileUpload.bind(this));
    }
  }

  showForm(formType) {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    if (formType === 'login') {
      loginForm.classList.remove('hidden');
      registerForm.classList.add('hidden');
    } else {
      registerForm.classList.remove('hidden');
      loginForm.classList.add('hidden');
    }
  }

  async handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
      await authService.signIn(email, password);
      this.showNotification('Logged in successfully!', 'success');
    } catch (error) {
      this.showNotification(error.message, 'error');
    }
  }

  async handleRegister(e) {
    e.preventDefault();
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;

    try {
      await authService.signUp(email, password);
      this.showNotification('Account created successfully!', 'success');
    } catch (error) {
      this.showNotification(error.message, 'error');
    }
  }

  async handleGoogleLogin() {
    try {
      await authService.signInWithGoogle();
      this.showNotification('Signed in with Google successfully!', 'success');
    } catch (error) {
      this.showNotification(error.message, 'error');
    }
  }

  async handleLogout() {
    try {
      await authService.signOut();
      this.showNotification('Logged out successfully!', 'success');
    } catch (error) {
      this.showNotification(error.message, 'error');
    }
  }

  async handleAddData() {
    if (!this.user) return;

    const title = document.getElementById('data-title').value;
    const content = document.getElementById('data-content').value;

    if (!title || !content) {
      this.showNotification('Please fill in both title and content', 'error');
      return;
    }

    try {
      await firestoreService.create('user_data', {
        userId: this.user.uid,
        title,
        content
      });

      document.getElementById('data-title').value = '';
      document.getElementById('data-content').value = '';
      
      this.showNotification('Data saved successfully!', 'success');
      this.loadUserData();
    } catch (error) {
      this.showNotification(error.message, 'error');
    }
  }

  async handleFileUpload() {
    if (!this.user) return;

    const fileInput = document.getElementById('file-input');
    const files = Array.from(fileInput.files);
    
    if (!files.length) {
      this.showNotification('Please select a file', 'error');
      return;
    }

    const progressDiv = document.getElementById('upload-progress');
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-text');
    
    progressDiv.classList.remove('hidden');

    try {
      const uploadResults = await storageService.uploadFiles(
        files,
        `users/${this.user.uid}/uploads`,
        (progress) => {
          progressFill.style.width = `${progress}%`;
          progressText.textContent = `${Math.round(progress)}%`;
        }
      );

      // Save file metadata to Firestore
      for (const result of uploadResults) {
        await firestoreService.create('files', {
          userId: this.user.uid,
          fileName: result.name,
          filePath: result.path,
          fileUrl: result.url,
          fileSize: result.size
        });
      }

      fileInput.value = '';
      progressDiv.classList.add('hidden');
      
      this.showNotification('Files uploaded successfully!', 'success');
      this.loadUserFiles();
    } catch (error) {
      progressDiv.classList.add('hidden');
      this.showNotification(error.message, 'error');
    }
  }

  async loadUserData() {
    if (!this.user) return;

    try {
      const data = await firestoreService.query('user_data', [
        { field: 'userId', operator: '==', value: this.user.uid }
      ]);

      this.displayUserData(data);
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  }

  async loadUserFiles() {
    if (!this.user) return;

    try {
      const files = await firestoreService.query('files', [
        { field: 'userId', operator: '==', value: this.user.uid }
      ]);

      this.displayFiles(files);
    } catch (error) {
      console.error('Error loading files:', error);
    }
  }

  displayUserData(data) {
    const container = document.getElementById('data-list');
    if (!container) return;

    container.innerHTML = data.map(item => `
      <div class="data-item">
        <h3>${item.title}</h3>
        <p>${item.content}</p>
        <small>Created: ${new Date(item.createdAt?.toDate()).toLocaleString()}</small>
        <button onclick="app.deleteData('${item.id}')" class="btn btn-danger">Delete</button>
      </div>
    `).join('');
  }

  displayFiles(files) {
    const container = document.getElementById('uploaded-files');
    if (!container) return;

    container.innerHTML = files.map(file => `
      <div class="file-item">
        <img src="${file.fileUrl}" alt="${file.fileName}" style="max-width: 200px; max-height: 200px;">
        <h4>${file.fileName}</h4>
        <p>Size: ${(file.fileSize / 1024).toFixed(2)} KB</p>
        <a href="${file.fileUrl}" target="_blank" class="btn btn-primary">View Full Size</a>
        <button onclick="app.deleteFile('${file.id}')" class="btn btn-danger">Delete</button>
      </div>
    `).join('');
  }

  async deleteData(dataId) {
    try {
      await firestoreService.delete('user_data', dataId);
      this.showNotification('Data deleted successfully!', 'success');
      this.loadUserData();
    } catch (error) {
      this.showNotification(error.message, 'error');
    }
  }

  async deleteFile(fileId) {
    try {
      const file = await firestoreService.getById('files', fileId);
      if (file) {
        await storageService.deleteFile(file.filePath);
        await firestoreService.delete('files', fileId);
        this.showNotification('File deleted successfully!', 'success');
        this.loadUserFiles();
      }
    } catch (error) {
      this.showNotification(error.message, 'error');
    }
  }

  updateUI() {
    const userInfo = document.getElementById('user-info');
    const authForms = document.getElementById('auth-forms');
    const appContent = document.getElementById('app-content');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const userEmail = document.getElementById('user-email');

    if (this.user) {
      // Show user info and app content
      userInfo.classList.remove('hidden');
      appContent.classList.remove('hidden');
      
      // Hide auth forms
      authForms.classList.add('hidden');
      loginForm.classList.add('hidden');
      registerForm.classList.add('hidden');
      
      // Update user email display
      if (userEmail) {
        userEmail.textContent = this.user.email;
      }
      
      // Load user data
      this.loadUserData();
      this.loadUserFiles();
    } else {
      // Show auth forms
      authForms.classList.remove('hidden');
      
      // Hide user info and app content
      userInfo.classList.add('hidden');
      appContent.classList.add('hidden');
      loginForm.classList.add('hidden');
      registerForm.classList.add('hidden');
    }
  }

  showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 15px 20px;
      border-radius: 5px;
      color: white;
      font-weight: bold;
      z-index: 1000;
      max-width: 300px;
      word-wrap: break-word;
    `;
    
    if (type === 'success') {
      notification.style.backgroundColor = '#4CAF50';
    } else {
      notification.style.backgroundColor = '#f44336';
    }
    
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 5000);
  }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.app = new App();
});
